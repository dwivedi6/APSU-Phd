# AICOF Simulation Package V4

This version introduces **distinct routing policies** for:
- shortest_path
- static_adaptive
- mlp
- gnn
- rl
- aicof

and a **valid ablation setup** for:
- AICOF-Full
- AICOF w/o RL
- AICOF w/o GNN
- AICOF w/o MLP
- AICOF w/o Congestion
- AICOF w/o Fault-Awareness

## Install
pip install -r requirements.txt

## Quick test
python run_all.py --quick --workers 2

## Full run
python run_all.py --workers 4
