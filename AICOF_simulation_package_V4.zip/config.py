from dataclasses import dataclass, field
@dataclass
class ExperimentConfig:
    node_sizes: list = field(default_factory=lambda: [64, 128, 256, 512])
    repetitions: int = 12
    packets_per_run: int = 1500
    max_steps_per_packet: int = 48
    traffic_pattern: str = "uniform"
    hotspot_fraction: float = 0.20
    failure_ratio_baseline: float = 0.05
    failure_ratio_scalability: float = 0.02
    failure_ratio_ai: float = 0.06
    random_seed: int = 42
CFG = ExperimentConfig()
