import random
from collections import defaultdict
from metrics import connectivity_ratio
from traffic import sample_packet_pairs
from routing import build_policy
def apply_failures(G, failure_ratio, rng):
    H = G.copy()
    if failure_ratio <= 0: return H, set()
    edges = list(H.edges()); k = int(len(edges) * failure_ratio)
    if k > 0 and edges: H.remove_edges_from(rng.sample(edges, min(k, len(edges))))
    return H, {n for n in H.nodes() if H.degree(n) == 0}
def simulate_routing(G, cfg, policy_name, failure_ratio=0.0, seed=42):
    rng = random.Random(seed); H, failed_nodes = apply_failures(G, failure_ratio, rng)
    if H.number_of_nodes() < 2 or H.number_of_edges() == 0:
        return {"connectivity_ratio":0.0,"throughput":0.0,"latency":None,"pdr":0.0,"energy_per_packet":None,"fault_recovery_score":0.0}
    policy = build_policy(policy_name, H, cfg, rng)
    packets = sample_packet_pairs(H.nodes(), cfg.packets_per_run, cfg.traffic_pattern, cfg.hotspot_fraction, rng)
    delivered = total_hops = 0; total_latency = total_energy = 0.0
    queue_len = defaultdict(int); link_load = defaultdict(int)
    for src, dst in packets:
        current = src; visited = {src}; success = False
        for _ in range(cfg.max_steps_per_packet):
            if current == dst: success = True; break
            nxt = policy.choose_next_hop(current, dst, queue_len, link_load, failed_nodes, visited)
            if nxt is None or not H.has_edge(current, nxt): break
            queue_len[nxt] += 1; link_load[(current, nxt)] += 1; total_hops += 1
            total_latency += 1.0 + 0.02*queue_len[nxt] + 0.01*link_load[(current, nxt)]
            total_energy += 0.55 + 0.008*H.degree(current) + 0.004*queue_len[nxt]
            current = nxt
            if current in visited: break
            visited.add(current)
            if current == dst: success = True; break
        if success: delivered += 1
    pdr = delivered / len(packets) if packets else 0.0
    throughput = delivered / max(1, cfg.max_steps_per_packet)
    latency = total_latency / delivered if delivered > 0 else None
    energy_per_packet = total_energy / delivered if delivered > 0 else None
    cr = connectivity_ratio(H); frs = 100.0 * (0.55 * pdr + 0.45 * cr)
    return {"connectivity_ratio": round(cr,4), "throughput": round(throughput,4), "latency": round(latency,4) if latency is not None else None,
            "pdr": round(100.0*pdr,2), "energy_per_packet": round(energy_per_packet,4) if energy_per_packet is not None else None,
            "fault_recovery_score": round(frs,2)}
