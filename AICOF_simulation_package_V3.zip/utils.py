import time
from pathlib import Path

def log(msg):
    print(msg, flush=True)

class StageTimer:
    def __init__(self, label):
        self.label = label
        self.t0 = None
    def __enter__(self):
        self.t0 = time.time()
        log(f"[START] {self.label}")
        return self
    def __exit__(self, exc_type, exc, tb):
        dt = time.time() - self.t0
        if exc is None:
            log(f"[DONE ] {self.label} in {dt:.1f} sec")
        else:
            log(f"[FAIL ] {self.label} after {dt:.1f} sec: {exc}")

def ensure_dir(path):
    Path(path).mkdir(parents=True, exist_ok=True)
