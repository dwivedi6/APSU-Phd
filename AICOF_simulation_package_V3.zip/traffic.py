import random

def sample_packet_pairs(nodes, count, pattern="uniform", hotspot_fraction=0.2, rng=None):
    rng = rng or random.Random()
    nodes = list(nodes)
    if len(nodes) < 2:
        return []
    pairs = []
    for _ in range(count):
        s = rng.choice(nodes)
        d = rng.choice(nodes)
        while d == s:
            d = rng.choice(nodes)
        pairs.append((s, d))
    return pairs
