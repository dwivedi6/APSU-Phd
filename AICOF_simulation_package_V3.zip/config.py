from dataclasses import dataclass, field

@dataclass
class ExperimentConfig:
    node_sizes: list = field(default_factory=lambda: [64, 128, 256, 512])
    repetitions: int = 30
    packets_per_run: int = 2000
    max_steps_per_packet: int = 64
    traffic_pattern: str = "uniform"
    hotspot_fraction: float = 0.20
    random_seed: int = 42

CFG = ExperimentConfig()
