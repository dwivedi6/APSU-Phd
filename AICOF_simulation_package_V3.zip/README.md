# AICOF Simulation Package V3 (Fixed)

## Install
```bash
pip install -r requirements.txt
```

## Quick run
```bash
python run_all.py --quick --workers 2
```

## Full run
```bash
python run_all.py --workers 4
```

## Output files
- topology_structural.csv
- baseline_traditional.csv
- scalability_latency.csv
- scalability_throughput.csv
- ai_vs_traditional.csv
- aicof_gain.csv
- ablation.csv
