from multiprocessing import Pool

def run_parallel(func, tasks, workers=1):
    if workers is None or workers <= 1:
        return [func(t) for t in tasks]
    with Pool(processes=workers) as pool:
        return pool.map(func, tasks)
