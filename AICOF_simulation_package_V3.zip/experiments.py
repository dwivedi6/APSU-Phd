import numpy as np
import pandas as pd
from config import CFG
from topologies import get_topology, resolve_valid_size
from metrics import structural_metrics
from simulator import simulate_routing
from parallel import run_parallel

TOPOLOGIES = ["hypercube", "torus", "fat-tree", "dragonfly", "pdn"]
AI_METHODS = ["shortest_path", "static_adaptive", "mlp", "gnn", "rl", "aicof"]
ABLATION_MAP = [
    ("AICOF-Full", "aicof"),
    ("AICOF w/o RL", "aicof_no_rl"),
    ("AICOF w/o GNN", "aicof_no_gnn"),
    ("AICOF w/o MLP", "aicof_no_mlp"),
    ("AICOF w/o Congestion", "aicof_no_congestion"),
    ("AICOF w/o Fault-Awareness", "aicof_no_fault"),
]

def avg_dict(dicts):
    keys = dicts[0].keys()
    out = {}
    for k in keys:
        vals = [d[k] for d in dicts if d[k] is not None]
        out[k] = round(float(np.mean(vals)), 4) if vals else None
    return out

def _sim_task(task):
    topo, requested_n, method, failure_ratio, rep = task
    n = resolve_valid_size(topo, requested_n)
    G = get_topology(topo, n)
    return topo, n, simulate_routing(G, CFG, method, failure_ratio=failure_ratio, seed=CFG.random_seed + rep)

def run_structural_table(node_count=64):
    rows = []
    for topo in TOPOLOGIES:
        n = resolve_valid_size(topo, node_count)
        G = get_topology(topo, n)
        m = structural_metrics(G)
        rows.append({
            "Topology": topo,
            "Nodes Used": n,
            "Node Degree": m["node_degree"],
            "Diameter": m["diameter"],
            "Avg. Path Length": m["avg_path_length"],
            "Path Diversity": m["path_diversity"],
            "Scalability": m["scalability"],
            "Fault Tolerance": m["fault_tolerance"],
        })
    return pd.DataFrame(rows)

def run_baseline_table(node_count=64, workers=1):
    rows = []
    for topo in TOPOLOGIES:
        tasks = [(topo, node_count, "shortest_path", 0.05, r) for r in range(CFG.repetitions)]
        results = [res for _, _, res in run_parallel(_sim_task, tasks, workers)]
        m = avg_dict(results)
        n = resolve_valid_size(topo, node_count)
        rows.append({
            "Topology": topo, "Nodes Used": n,
            "Connectivity Ratio": m["connectivity_ratio"], "Throughput": m["throughput"],
            "Avg. Latency": m["latency"], "PDR (%)": m["pdr"],
            "Energy / Packet": m["energy_per_packet"], "Fault Recovery Score": m["fault_recovery_score"],
        })
    return pd.DataFrame(rows)

def run_scalability_tables(workers=1):
    latency_rows, throughput_rows = [], []
    for topo in TOPOLOGIES:
        lat_row, thr_row = {"Topology": topo}, {"Topology": topo}
        for req_n in CFG.node_sizes:
            tasks = [(topo, req_n, "shortest_path", 0.02, r) for r in range(CFG.repetitions)]
            results = [res for _, _, res in run_parallel(_sim_task, tasks, workers)]
            m = avg_dict(results)
            n = resolve_valid_size(topo, req_n)
            col = f"{req_n} (used {n})" if n != req_n else str(req_n)
            lat_row[col] = m["latency"]
            thr_row[col] = m["throughput"]
        latency_rows.append(lat_row)
        throughput_rows.append(thr_row)
    return pd.DataFrame(latency_rows), pd.DataFrame(throughput_rows)

def run_ai_vs_traditional(node_count=256, workers=1):
    rows = []
    for method in AI_METHODS:
        tasks = []
        for topo in TOPOLOGIES:
            for r in range(CFG.repetitions):
                tasks.append((topo, node_count, method, 0.05, r))
        results = [res for _, _, res in run_parallel(_sim_task, tasks, workers)]
        m = avg_dict(results)
        rows.append({
            "Method": method, "Connectivity Ratio": m["connectivity_ratio"], "Throughput": m["throughput"],
            "Avg. Latency": m["latency"], "PDR (%)": m["pdr"], "Energy / Packet": m["energy_per_packet"],
            "Fault Recovery Score": m["fault_recovery_score"],
        })
    return pd.DataFrame(rows)

def run_aicof_gain(node_count=256, workers=1):
    rows = []
    for topo in TOPOLOGIES:
        base_tasks = [(topo, node_count, "shortest_path", 0.05, r) for r in range(CFG.repetitions)]
        ai_tasks = [(topo, node_count, "aicof", 0.05, r) for r in range(CFG.repetitions)]
        base_results = [res for _, _, res in run_parallel(_sim_task, base_tasks, workers)]
        ai_results = [res for _, _, res in run_parallel(_sim_task, ai_tasks, workers)]
        b = avg_dict(base_results)
        a = avg_dict(ai_results)
        n = resolve_valid_size(topo, node_count)
        def pct_gain(new, old, inverse=False):
            if old in [0, None] or new is None:
                return None
            return round(100.0 * ((old - new) / old if inverse else (new - old) / old), 2)
        rows.append({
            "Topology": topo, "Nodes Used": n,
            "Δ Connectivity (%)": pct_gain(a["connectivity_ratio"], b["connectivity_ratio"]),
            "Δ Throughput (%)": pct_gain(a["throughput"], b["throughput"]),
            "Δ Latency (%)": pct_gain(a["latency"], b["latency"], inverse=True),
            "Δ PDR (%)": pct_gain(a["pdr"], b["pdr"]),
            "Δ Energy (%)": pct_gain(a["energy_per_packet"], b["energy_per_packet"], inverse=True),
            "Δ Fault Recovery (%)": pct_gain(a["fault_recovery_score"], b["fault_recovery_score"]),
        })
    return pd.DataFrame(rows)

def run_ablation(node_count=256, workers=1):
    rows = []
    for label, method in ABLATION_MAP:
        tasks = []
        for topo in TOPOLOGIES:
            for r in range(CFG.repetitions):
                tasks.append((topo, node_count, method, 0.05, r))
        results = [res for _, _, res in run_parallel(_sim_task, tasks, workers)]
        m = avg_dict(results)
        rows.append({
            "Model Variant": label, "Connectivity Ratio": m["connectivity_ratio"], "Throughput": m["throughput"],
            "Avg. Latency": m["latency"], "PDR (%)": m["pdr"], "Energy / Packet": m["energy_per_packet"],
            "Fault Recovery Score": m["fault_recovery_score"],
        })
    return pd.DataFrame(rows)
