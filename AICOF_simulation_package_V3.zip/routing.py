import networkx as nx

class BasePolicy:
    def __init__(self, G, cfg, rng=None):
        self.G = G
        self.cfg = cfg

    def dist(self, u, v):
        try:
            return nx.shortest_path_length(self.G, u, v)
        except nx.NetworkXNoPath:
            return 10**9

class ShortestPathPolicy(BasePolicy):
    def choose_next_hop(self, current, dst, queue_len, link_load, visited=None):
        nbrs = list(self.G.neighbors(current))
        if not nbrs:
            return None
        nbrs.sort(key=lambda x: self.dist(x, dst))
        return nbrs[0]

class AdaptivePolicy(BasePolicy):
    def choose_next_hop(self, current, dst, queue_len, link_load, visited=None):
        nbrs = list(self.G.neighbors(current))
        if not nbrs:
            return None
        visited = visited or set()
        best, best_score = None, -1e18
        curr = self.dist(current, dst)
        for v in nbrs:
            nd = self.dist(v, dst)
            progress = curr - nd
            score = 4*progress - 2*nd - 0.2*queue_len.get(v,0) - 0.1*link_load.get((current,v),0) + 0.1*self.G.degree(v)
            if v in visited:
                score -= 3
            if score > best_score:
                best, best_score = v, score
        return best

def build_policy(name, G, cfg, rng=None):
    name = name.lower()
    if name == "shortest_path":
        return ShortestPathPolicy(G, cfg, rng)
    return AdaptivePolicy(G, cfg, rng)
