"""Run the reproducibility workflow for the topology-classification experiment."""
from pathlib import Path
import subprocess, sys

ROOT = Path(__file__).resolve().parents[1]
script = ROOT / "src" / "reproduce_results.py"
subprocess.run([sys.executable, str(script)], check=True)
print("\nReproducibility run completed.")
print("Results are in:", ROOT / "results")
