"""Reproduce the classifier results reported in the manuscript.

The supplied CSV is the exact 400-instance feature dataset used for the manuscript draft.
Training: 64/128/256-node graphs; Test: all 512-node graphs.
"""
from pathlib import Path
import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "topology_classification_dataset.csv"
OUT = ROOT / "results"
OUT.mkdir(exist_ok=True)

FEATURES = ["avg_degree", "diameter", "avg_path_length", "density",
            "path_diversity", "scalability", "connectivity_ratio"]
TARGET = "topology"

# Configurations used in the manuscript draft.
models = {
    "Decision Tree": DecisionTreeClassifier(max_depth=6, random_state=42),
    "KNN": Pipeline([("scale", StandardScaler()), ("model", KNeighborsClassifier(n_neighbors=5))]),
    "SVM": Pipeline([("scale", StandardScaler()), ("model", SVC(kernel="rbf", C=2, random_state=42))]),
    "Random Forest": RandomForestClassifier(n_estimators=200, max_depth=8, random_state=42),
    "MLP": Pipeline([("scale", StandardScaler()), ("model", MLPClassifier(hidden_layer_sizes=(32,16), max_iter=2000, random_state=42))]),
}

df = pd.read_csv(DATA)
train = df[df["nodes"].isin([64,128,256])].copy()
test = df[df["nodes"] == 512].copy()
X_train, y_train = train[FEATURES], train[TARGET]
X_test, y_test = test[FEATURES], test[TARGET]

rows = []
for name, model in models.items():
    model.fit(X_train, y_train)
    pred = model.predict(X_test)
    rows.append({
        "Classifier": name,
        "Accuracy": accuracy_score(y_test, pred),
        "Precision_weighted": precision_score(y_test, pred, average="weighted", zero_division=0),
        "Recall_weighted": recall_score(y_test, pred, average="weighted", zero_division=0),
        "F1_weighted": f1_score(y_test, pred, average="weighted", zero_division=0),
    })
    if name == "Decision Tree":
        labels = sorted(y_test.unique())
        cm = confusion_matrix(y_test, pred, labels=labels)
        pd.DataFrame(cm, index=labels, columns=labels).to_csv(OUT / "decision_tree_confusion_matrix.csv")
    if name == "Random Forest":
        fi = pd.DataFrame({"feature": FEATURES, "importance": model.feature_importances_})
        fi = fi.sort_values("importance", ascending=False)
        fi.to_csv(OUT / "random_forest_feature_importance.csv", index=False)

results = pd.DataFrame(rows)
results.to_csv(OUT / "classification_results.csv", index=False)
print(results.to_string(index=False))
print("\nTraining instances:", len(train), "Test instances:", len(test))
