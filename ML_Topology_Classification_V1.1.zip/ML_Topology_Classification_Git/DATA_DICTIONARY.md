# Dataset dictionary

The file `data/topology_classification_dataset.csv` contains the 400 graph-level feature records used for the manuscript experiment.

| Column | Meaning |
|---|---|
| topology | Topology-family label: Hypercube, Torus, Fat-Tree, Dragonfly, or PDN |
| nodes | Number of processors/nodes: 64, 128, 256, or 512 |
| failure_rate | Controlled random edge-failure rate: 0, 0.01, 0.02, or 0.05 |
| rep | Independent repetition index (0–4) |
| avg_degree | Average node degree, 2|E|/|V| |
| diameter | Graph diameter |
| avg_path_length | Average shortest-path length |
| density | Graph density |
| path_diversity | Simulation-defined structural proxy: density × average degree |
| scalability | Inverse average path length used as a lightweight structural proxy in the original dataset |
| connectivity_ratio | Largest connected-component size divided by total nodes |

## Split used in the manuscript

- Training: 64, 128, and 256 nodes = 300 records
- Held-out test: 512 nodes = 100 records
- Five topology classes; 20 test records per class
