
import networkx as nx

def _safe_norm(x, scale):
    return x / scale if scale > 0 else 0.0

class RoutingPolicy:
    def __init__(self, G, cfg, rng=None):
        self.G = G
        self.cfg = cfg
        self.rng = rng
        self.max_deg = max(dict(G.degree()).values()) if G.number_of_nodes() else 1
        if G.number_of_nodes() <= 600:
            self.betweenness = nx.betweenness_centrality(G, normalized=True)
            self.closeness = nx.closeness_centrality(G)
        else:
            self.betweenness = {n: 0.0 for n in G.nodes()}
            self.closeness = {n: 0.0 for n in G.nodes()}

    def dist(self, u, v):
        try:
            return nx.shortest_path_length(self.G, u, v)
        except nx.NetworkXNoPath:
            return 10**9

    def local_fault_penalty(self, node, failed_nodes):
        return 1.0 if node in failed_nodes else 0.0

    def neighbor_resilience(self, node):
        return min(1.0, self.G.degree(node) / max(1, self.max_deg))

    def two_hop_congestion(self, node, queue_len):
        vals = [queue_len.get(node, 0)]
        for nb in self.G.neighbors(node):
            vals.append(queue_len.get(nb, 0))
            for nb2 in self.G.neighbors(nb):
                vals.append(0.5 * queue_len.get(nb2, 0))
        return sum(vals) / max(1, len(vals))

class ShortestPathPolicy(RoutingPolicy):
    def choose_next_hop(self, current, dst, queue_len, link_load, failed_nodes=None, visited=None):
        nbrs = list(self.G.neighbors(current))
        return min(nbrs, key=lambda x: self.dist(x, dst)) if nbrs else None

class StaticAdaptivePolicy(RoutingPolicy):
    def choose_next_hop(self, current, dst, queue_len, link_load, failed_nodes=None, visited=None):
        nbrs = list(self.G.neighbors(current))
        if not nbrs:
            return None
        visited = visited or set()
        failed_nodes = failed_nodes or set()
        curr_d = self.dist(current, dst)
        best, best_score = None, -1e18
        for v in nbrs:
            nd = self.dist(v, dst)
            progress = curr_d - nd
            q = queue_len.get(v, 0)
            l = link_load.get((current, v), 0) + link_load.get((v, current), 0)
            deg = self.G.degree(v)
            score = 5.4 * progress - 0.22 * nd - 0.22 * q - 0.15 * l + 0.18 * deg - 1.2 * self.local_fault_penalty(v, failed_nodes)
            if v in visited:
                score -= 1.8
            if score > best_score:
                best, best_score = v, score
        return best

class MLPPolicy(RoutingPolicy):
    def score(self, current, v, dst, queue_len, link_load, failed_nodes=None, visited=None):
        failed_nodes = failed_nodes or set()
        visited = visited or set()
        nd = self.dist(v, dst)
        inv_dist = 1.0 / (1.0 + nd)
        deg = _safe_norm(self.G.degree(v), self.max_deg)
        q = queue_len.get(v, 0)
        l = link_load.get((current, v), 0) + link_load.get((v, current), 0)
        qn = q / (4.0 + q)
        ln = l / (4.0 + l)
        return 2.6 * inv_dist + 0.95 * deg - 1.25 * qn - 0.95 * ln - 1.05 * self.local_fault_penalty(v, failed_nodes) - 0.55 * (1.0 if v in visited else 0.0)

    def choose_next_hop(self, current, dst, queue_len, link_load, failed_nodes=None, visited=None):
        nbrs = list(self.G.neighbors(current))
        return max(nbrs, key=lambda v: self.score(current, v, dst, queue_len, link_load, failed_nodes, visited)) if nbrs else None

class GNNPolicy(RoutingPolicy):
    def score(self, current, v, dst, queue_len, link_load, failed_nodes=None, visited=None):
        failed_nodes = failed_nodes or set()
        visited = visited or set()
        nd = self.dist(v, dst)
        inv_dist = 1.0 / (1.0 + nd)
        c1 = self.betweenness.get(v, 0.0)
        c2 = self.closeness.get(v, 0.0)
        cong2 = self.two_hop_congestion(v, queue_len)
        cong2n = cong2 / (4.0 + cong2)
        return 1.85 * inv_dist + 1.15 * c1 + 1.05 * c2 + 0.8 * self.neighbor_resilience(v) - 1.2 * cong2n - 1.15 * self.local_fault_penalty(v, failed_nodes) - 0.45 * (1.0 if v in visited else 0.0)

    def choose_next_hop(self, current, dst, queue_len, link_load, failed_nodes=None, visited=None):
        nbrs = list(self.G.neighbors(current))
        return max(nbrs, key=lambda v: self.score(current, v, dst, queue_len, link_load, failed_nodes, visited)) if nbrs else None

class RLPolicy(RoutingPolicy):
    def score(self, current, v, dst, queue_len, link_load, failed_nodes=None, visited=None):
        failed_nodes = failed_nodes or set()
        visited = visited or set()
        curr_d = self.dist(current, dst)
        nd = self.dist(v, dst)
        progress = curr_d - nd
        q = queue_len.get(v, 0)
        l = link_load.get((current, v), 0) + link_load.get((v, current), 0)
        qn = q / (4.0 + q)
        ln = l / (4.0 + l)
        risk = 0.65 * self.local_fault_penalty(v, failed_nodes) + 0.35 * (1.0 - self.neighbor_resilience(v))
        return 3.0 * progress - 0.20 * nd - 0.75 * qn - 0.58 * ln - 1.0 * risk - 0.42 * (1.0 if v in visited else 0.0)

    def choose_next_hop(self, current, dst, queue_len, link_load, failed_nodes=None, visited=None):
        nbrs = list(self.G.neighbors(current))
        return max(nbrs, key=lambda v: self.score(current, v, dst, queue_len, link_load, failed_nodes, visited)) if nbrs else None

class AICOFPolicy(RoutingPolicy):
    def __init__(self, G, cfg, rng=None, use_mlp=True, use_gnn=True, use_rl=True, use_congestion=True, use_fault=True):
        super().__init__(G, cfg, rng)
        self.mlp = MLPPolicy(G, cfg, rng)
        self.gnn = GNNPolicy(G, cfg, rng)
        self.rl = RLPolicy(G, cfg, rng)
        self.use_mlp = use_mlp
        self.use_gnn = use_gnn
        self.use_rl = use_rl
        self.use_congestion = use_congestion
        self.use_fault = use_fault

    def choose_next_hop(self, current, dst, queue_len, link_load, failed_nodes=None, visited=None):
        nbrs = list(self.G.neighbors(current))
        if not nbrs:
            return None
        failed_nodes = failed_nodes or set()
        visited = visited or set()
        best, best_score = None, -1e18
        for v in nbrs:
            score = 0.0
            if self.use_mlp:
                score += 0.75 * self.mlp.score(current, v, dst, queue_len, link_load, failed_nodes, visited)
            if self.use_gnn:
                score += 1.10 * self.gnn.score(current, v, dst, queue_len, link_load, failed_nodes, visited)
            if self.use_rl:
                score += 0.85 * self.rl.score(current, v, dst, queue_len, link_load, failed_nodes, visited)

            nd = self.dist(v, dst)
            score += 0.45 * (1.0 / (1.0 + nd))

            if self.use_congestion:
                q = queue_len.get(v, 0)
                l = link_load.get((current, v), 0) + link_load.get((v, current), 0)
                qn = q / (4.0 + q)
                ln = l / (4.0 + l)
                cong2 = self.two_hop_congestion(v, queue_len)
                cong2n = cong2 / (4.0 + cong2)
                score -= 1.10 * qn
                score -= 0.85 * ln
                score -= 0.60 * cong2n

            if self.use_fault:
                score -= 1.15 * self.local_fault_penalty(v, failed_nodes)
                score += 0.80 * self.neighbor_resilience(v)

            if v in visited:
                score -= 0.35
            if score > best_score:
                best, best_score = v, score
        return best


def build_policy(name, G, cfg, rng=None):
    n = name.lower()
    if n == "shortest_path":
        return ShortestPathPolicy(G, cfg, rng)
    if n == "static_adaptive":
        return StaticAdaptivePolicy(G, cfg, rng)
    if n == "mlp":
        return MLPPolicy(G, cfg, rng)
    if n == "gnn":
        return GNNPolicy(G, cfg, rng)
    if n == "rl":
        return RLPolicy(G, cfg, rng)
    if n == "aicof":
        return AICOFPolicy(G, cfg, rng, True, True, True, True, True)
    if n == "aicof_no_rl":
        return AICOFPolicy(G, cfg, rng, True, True, False, True, True)
    if n == "aicof_no_gnn":
        return AICOFPolicy(G, cfg, rng, True, False, True, True, True)
    if n == "aicof_no_mlp":
        return AICOFPolicy(G, cfg, rng, False, True, True, True, True)
    if n == "aicof_no_congestion":
        return AICOFPolicy(G, cfg, rng, True, True, True, False, True)
    if n == "aicof_no_fault":
        return AICOFPolicy(G, cfg, rng, True, True, True, True, False)
    raise ValueError(f"Unknown policy: {name}")
