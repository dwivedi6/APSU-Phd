# AICOF Simulation Package V5 — Complete Function Reference

## 1. Overview

This package is **AICOF Simulation Package V5**, a NetworkX-based simulation framework for evaluating processor interconnection-network topologies and comparing traditional, AI-assisted, and integrated AICOF routing strategies.

The supplied V5 source is specifically described as being tuned for:

- stronger separation between AI routing methods,
- a meaningful AICOF ablation study,
- stronger congestion and two-hop congestion penalties,
- stronger fault-awareness,
- increased AI-experiment failure ratio,
- method-specific load and failure behavior.

The core integrated routing policy combines:

```text
MLP-style scoring
        +
GNN-style graph features
        +
RL-style adaptive scoring
        +
Congestion awareness
        +
Fault awareness
```

### Important implementation note

The supplied V5 source implements `MLPPolicy`, `GNNPolicy`, and `RLPolicy` as **weighted scoring policies**. It does not contain an actual trained neural MLP, graph neural network, or PPO/RL training loop.

Therefore, the technically accurate description of this source is an **AI-inspired / score-based AICOF simulation framework**, unless the implementation is subsequently replaced or extended with genuinely trained models.

---

# 2. Package Contents

The supplied archive contains:

```text
AICOF_simulation_package_V5/
│
├── config.py
├── topologies.py
├── traffic.py
├── metrics.py
├── routing.py
├── simulator.py
├── experiments.py
├── parallel.py
├── latex_export.py
├── utils.py
├── run_all.py
├── requirements.txt
└── README.md
```

The package does not contain a pre-generated `results/` directory. The result files are generated when `run_all.py` executes.

---

# 3. Overall Architecture

The execution flow is:

```text
                    run_all.py
                        |
                        v
                  experiments.py
                        |
          +-------------+-------------+
          |             |             |
          v             v             v
     topologies.py  simulator.py  parallel.py
          |             |
          |        +----+----+
          |        |         |
          v        v         v
      Network    routing   traffic
                    |
                    v
                 metrics
                    |
                    v
             pandas DataFrames
                    |
                    v
             latex_export.py
                    |
              +-----+-----+
              |           |
             CSV         TEX
```

---

# 4. Installation

The supplied `requirements.txt` contains:

```text
networkx>=3.2
numpy>=1.24
pandas>=2.0
```

Install with:

```bash
python -m pip install -r requirements.txt
```

or:

```bash
pip install -r requirements.txt
```

Verify the environment:

```bash
python -c "import networkx, numpy, pandas; print('Environment OK')"
```

---

# 5. Main Execution Commands

## 5.1 Quick validation

```bash
python run_all.py --quick --workers 2
```

Quick mode changes the global experiment configuration to:

```text
repetitions = 4
packets_per_run = 500
max_steps_per_packet = 32
```

The purpose is to verify the complete pipeline before performing the full experiment.

## 5.2 Full experiment

```bash
python run_all.py --workers 4
```

The full run uses the values defined in `config.py`:

```text
node_sizes = [64, 128, 256, 512]
repetitions = 12
packets_per_run = 1800
max_steps_per_packet = 56
```

## 5.3 Single-worker debugging

```bash
python run_all.py --workers 1
```

This is useful when diagnosing an error.

## 5.4 Parallel execution

```bash
python run_all.py --workers 4
```

The `--workers` argument controls multiprocessing.

---

# 6. `config.py`

This module defines the global experiment configuration.

## 6.1 `ExperimentConfig`

```python
@dataclass
class ExperimentConfig:
    node_sizes: list = field(
        default_factory=lambda: [64, 128, 256, 512]
    )
    repetitions: int = 12
    packets_per_run: int = 1800
    max_steps_per_packet: int = 56
    traffic_pattern: str = "uniform"
    hotspot_fraction: float = 0.22
    failure_ratio_baseline: float = 0.05
    failure_ratio_scalability: float = 0.02
    failure_ratio_ai: float = 0.08
    random_seed: int = 42
```

### Purpose

Stores all global simulation parameters.

### Parameters

| Parameter | Purpose | Default |
|---|---|---:|
| `node_sizes` | Network sizes for scalability analysis | `[64,128,256,512]` |
| `repetitions` | Number of repeated runs | `12` |
| `packets_per_run` | Packets simulated per run | `1800` |
| `max_steps_per_packet` | Maximum routing hops/steps | `56` |
| `traffic_pattern` | Traffic model | `uniform` |
| `hotspot_fraction` | Fraction of hotspot nodes | `0.22` |
| `failure_ratio_baseline` | Baseline failure ratio | `0.05` |
| `failure_ratio_scalability` | Scalability failure ratio | `0.02` |
| `failure_ratio_ai` | AI-comparison failure ratio | `0.08` |
| `random_seed` | Base random seed | `42` |

---

# 7. `CFG`

```python
CFG = ExperimentConfig()
```

## Purpose

Creates the global configuration instance.

Other modules import this object, especially:

```text
experiments.py
run_all.py
```

---

# 8. `topologies.py`

This module generates the five network topologies used throughout the experiments:

```text
Hypercube
Torus
Fat-tree
Dragonfly
PDN
```

---

# 9. `build_hypercube(n)`

```python
build_hypercube(n)
```

## Purpose

Creates an `n`-node hypercube using:

```python
nx.hypercube_graph(dim)
```

where:

```text
dim = log2(n)
```

The function verifies that `n` is an exact power of two.

Valid examples:

```text
64
128
256
512
```

Invalid example:

```text
100
```

For an invalid value it raises:

```text
ValueError: Hypercube requires power-of-2 size.
```

## Used by

```text
get_topology()
resolve_valid_size()
run_structural_table()
run_baseline_table()
run_scalability_tables()
run_ai_vs_traditional()
run_aicof_gain()
run_ablation()
```

---

# 10. `build_torus(n)`

```python
build_torus(n)
```

## Purpose

Creates a periodic two-dimensional grid:

```python
nx.grid_2d_graph(
    side,
    side,
    periodic=True
)
```

The requested node count must be a perfect square.

Examples:

```text
64  = 8 × 8
256 = 16 × 16
```

If the value is not a perfect square, a `ValueError` is raised.

---

# 11. `build_fat_tree(n)`

```python
build_fat_tree(n)
```

## Purpose

Creates a balanced-tree approximation used as the package's fat-tree topology.

The source uses:

```python
nx.balanced_tree(r, depth)
```

with:

```python
r = 4
```

The generated graph is truncated when it contains more nodes than requested.

### Important note

This implementation is a **balanced-tree approximation**, not a complete conventional datacenter fat-tree architecture.

---

# 12. `build_dragonfly(n)`

```python
build_dragonfly(n)
```

## Purpose

Creates a simplified Dragonfly-like network.

The function:

1. Determines a group size.
2. Creates groups of nodes.
3. Fully connects nodes inside each group.
4. Adds inter-group links.

The implementation therefore provides a graph abstraction of Dragonfly rather than a complete hardware-level Dragonfly model.

---

# 13. `build_pdn(n)`

```python
build_pdn(n)
```

## Purpose

Creates the Perfect Difference Network-style topology used by the package.

The source uses modular offsets:

```python
offsets = [1, 3, 7]
```

and adds both positive and negative offset edges.

---

# 14. `nearest_power_of_two(n)`

```python
nearest_power_of_two(n)
```

## Purpose

Finds the closest power-of-two network size.

This is required for valid hypercube construction.

Example:

```text
requested = 100
nearest valid size ≈ 128 or 64
```

The function chooses the closer supported value.

---

# 15. `nearest_perfect_square(n)`

```python
nearest_perfect_square(n)
```

## Purpose

Finds the closest perfect-square size for torus construction.

It evaluates neighboring square candidates around:

```python
sqrt(n)
```

with a minimum candidate of 4.

---

# 16. `resolve_valid_size(topology, requested_n)`

```python
resolve_valid_size(topology, requested_n)
```

## Purpose

Converts the requested network size into a topology-compatible size.

Rules:

```text
hypercube → nearest power of two
torus     → nearest perfect square
fat-tree  → requested size
dragonfly → requested size
pdn       → requested size
```

This function is called before topology construction in the experiment functions.

---

# 17. `get_topology(name, n)`

```python
get_topology(name, n)
```

## Purpose

Central topology factory.

Supported names:

```text
hypercube
torus
fat-tree
dragonfly
pdn
```

Example:

```python
G = get_topology("hypercube", 64)
```

An unknown topology raises:

```text
ValueError: Unknown topology
```

---

# 18. `traffic.py`

This module creates source-destination packet pairs.

---

# 19. `sample_packet_pairs()`

```python
sample_packet_pairs(
    nodes,
    count,
    pattern="uniform",
    hotspot_fraction=0.2,
    rng=None
)
```

## Purpose

Generates traffic requests for packet-level simulation.

### Parameters

| Parameter | Meaning |
|---|---|
| `nodes` | Network node collection |
| `count` | Number of packets |
| `pattern` | Traffic pattern |
| `hotspot_fraction` | Fraction of hotspot nodes |
| `rng` | Random generator |

---

## 19.1 Uniform traffic

With:

```python
pattern="uniform"
```

both source and destination are selected randomly from the network.

The function prevents:

```text
source == destination
```

---

## 19.2 Hotspot traffic

With:

```python
pattern="hotspot"
```

the first:

```python
int(len(nodes) * hotspot_fraction)
```

nodes are designated as hotspots.

The destination is selected from hotspots with probability:

```text
0.6
```

Otherwise it is selected from all nodes.

---

## Return value

The function returns:

```python
[
    (source, destination),
    ...
]
```

---

# 20. `metrics.py`

This module computes structural and connectivity metrics.

---

# 21. `safe_average_shortest_path_length(G)`

```python
safe_average_shortest_path_length(G)
```

## Purpose

Computes the average shortest-path length.

For a connected graph:

```python
nx.average_shortest_path_length(G)
```

is used directly.

For a disconnected graph:

```text
largest connected component
```

is selected and the average shortest path is calculated on that component.

This prevents failures caused by disconnected graphs.

---

# 22. `structural_metrics(G)`

```python
structural_metrics(G)
```

## Purpose

Calculates structural characteristics of a network.

It returns:

```python
{
    "node_degree": ...,
    "diameter": ...,
    "avg_path_length": ...,
    "path_diversity": ...,
    "scalability": ...,
    "fault_tolerance": ...
}
```

---

## 22.1 Node Degree

The mean degree of all nodes:

```text
average node degree
```

---

## 22.2 Diameter

The maximum shortest-path distance.

If the graph is disconnected, the diameter of the largest connected component is used.

---

## 22.3 Average Path Length

Calculated through:

```python
safe_average_shortest_path_length()
```

---

## 22.4 Path Diversity

The current implementation defines:

```text
path diversity =
network density × average node degree
```

This is a simulation-defined proxy.

It should **not** be interpreted as a conventional edge-disjoint-path or node-disjoint-path count.

---

## 22.5 Scalability

The source defines:

```text
scalability =
1 / average path length
```

This is a normalized structural indicator.

---

## 22.6 Fault Tolerance

The source calculates:

```text
fault tolerance =
(edge connectivity + node connectivity) / 2
```

using NetworkX:

```python
nx.edge_connectivity(G)
nx.node_connectivity(G)
```

---

# 23. `connectivity_ratio(G)`

```python
connectivity_ratio(G)
```

## Purpose

Measures the proportion of nodes contained in the largest connected component.

Formula:

```text
Connectivity Ratio =
largest connected component size
--------------------------------
total number of nodes
```

Range:

```text
0 to 1
```

Higher values indicate stronger network connectivity.

---

# 24. `routing.py`

This module contains all routing policies.

The available policies are:

```text
Shortest Path
Static Adaptive
MLP
GNN
RL
AICOF
```

plus five AICOF ablation variants.

---

# 25. `_safe_norm(x, scale)`

```python
_safe_norm(x, scale)
```

## Purpose

Safely normalizes a value:

```text
x / scale
```

If:

```text
scale <= 0
```

the function returns:

```text
0.0
```

## Used by

```text
MLPPolicy.score()
```

---

# 26. `RoutingPolicy`

```python
RoutingPolicy(G, cfg, rng=None)
```

## Purpose

Base class inherited by all routing policies.

It stores:

```text
Graph
Configuration
Random generator
Maximum node degree
Betweenness centrality
Closeness centrality
```

For graphs with:

```text
number of nodes <= 600
```

the implementation calculates:

```python
nx.betweenness_centrality()
nx.closeness_centrality()
```

For larger graphs both centrality dictionaries are initialized to zero to avoid expensive calculations.

---

# 27. `RoutingPolicy.dist()`

```python
dist(u, v)
```

## Purpose

Returns shortest-path distance between two nodes.

If no path exists, it returns:

```text
10^9
```

which acts as a very large distance penalty.

---

# 28. `RoutingPolicy.local_fault_penalty()`

```python
local_fault_penalty(node, failed_nodes)
```

Returns:

```text
1.0 → node is failed
0.0 → node is not failed
```

This is used by adaptive and AI-style policies.

---

# 29. `RoutingPolicy.neighbor_resilience()`

```python
neighbor_resilience(node)
```

## Purpose

Provides a normalized degree-based resilience indicator.

Formula:

```text
degree(node) / maximum degree
```

with the result capped at:

```text
1.0
```

---

# 30. `RoutingPolicy.two_hop_congestion()`

```python
two_hop_congestion(node, queue_len)
```

## Purpose

Estimates local congestion around a candidate node.

It includes:

```text
current node queue
one-hop neighbor queues
two-hop neighbor queues
```

Two-hop queue values are weighted by:

```text
0.5
```

This feature is particularly important for:

```text
GNNPolicy
AICOFPolicy
```

---

# 31. `ShortestPathPolicy`

## `choose_next_hop()`

```python
choose_next_hop(
    current,
    dst,
    queue_len,
    link_load,
    failed_nodes=None,
    visited=None
)
```

## Purpose

Traditional routing policy.

For each neighbor of the current node, it calculates:

```text
shortest-path distance from neighbor to destination
```

and selects the neighbor with the minimum distance.

This is the main traditional baseline.

---

# 32. `StaticAdaptivePolicy`

## `choose_next_hop()`

Selects a next hop using a weighted adaptive score.

The score combines:

```text
destination progress
remaining distance
queue length
link load
node degree
fault penalty
visited-node penalty
```

The supplied coefficients are:

```text
progress        +5.4
distance        -0.22
queue           -0.22
link load       -0.15
degree          +0.18
fault           -1.20
visited         -1.80
```

The neighbor with the highest score is selected.

---

# 33. `MLPPolicy`

## `score()`

```python
score(
    current,
    v,
    dst,
    queue_len,
    link_load,
    failed_nodes=None,
    visited=None
)
```

## Purpose

Calculates a local next-hop score from features representing:

```text
distance
degree
queue congestion
link load
fault status
visited status
```

The score is:

```text
2.60 × inverse distance
+ 0.95 × normalized degree
- 1.25 × normalized queue
- 0.95 × normalized link load
- 1.05 × fault penalty
- 0.55 × visited penalty
```

## `choose_next_hop()`

Selects the neighbor with the maximum MLP-style score.

### Important implementation note

This is called `MLPPolicy`, but the supplied V5 source does not create or train an actual multilayer perceptron.

There is no:

```text
PyTorch model
training loop
backpropagation
learned weights
```

The coefficients are explicitly defined mathematical weights.

---

# 34. `GNNPolicy`

## `score()`

Uses graph-derived features:

```text
inverse destination distance
betweenness centrality
closeness centrality
neighbor resilience
two-hop congestion
fault status
visited status
```

The score is:

```text
1.85 × inverse distance
+ 1.15 × betweenness
+ 1.05 × closeness
+ 0.80 × neighbor resilience
- 1.20 × normalized two-hop congestion
- 1.15 × fault penalty
- 0.45 × visited penalty
```

## `choose_next_hop()`

Chooses the neighbor with the maximum score.

### Important implementation note

The source does not implement a trained GNN.

It does not use:

```text
PyTorch Geometric
GCN
GAT
GraphSAGE
GraphConv
```

The GNN label refers to the use of graph-structural features in the routing score.

---

# 35. `RLPolicy`

## `score()`

Uses:

```text
destination progress
remaining distance
queue congestion
link load
fault risk
neighbor resilience
visited status
```

The risk term is:

```text
risk =
0.65 × fault penalty
+
0.35 × (1 - neighbor resilience)
```

The complete score is:

```text
3.00 × progress
- 0.20 × distance
- 0.75 × normalized queue
- 0.58 × normalized link load
- 1.00 × risk
- 0.42 × visited penalty
```

## `choose_next_hop()`

Selects the neighbor with the maximum score.

### Important implementation note

The supplied V5 source does not implement PPO or another trained reinforcement-learning algorithm.

There is no:

```text
Stable-Baselines3
PPO
policy network
training episodes
reward-learning loop
```

Therefore this should be described as an RL-style adaptive scoring policy.

---

# 36. `AICOFPolicy`

```python
AICOFPolicy(
    G,
    cfg,
    rng=None,
    use_mlp=True,
    use_gnn=True,
    use_rl=True,
    use_congestion=True,
    use_fault=True
)
```

## Purpose

Implements the integrated AICOF routing strategy.

It internally creates:

```python
self.mlp = MLPPolicy(...)
self.gnn = GNNPolicy(...)
self.rl = RLPolicy(...)
```

and combines their scores.

---

# 37. AICOF Component Switches

| Parameter | Purpose |
|---|---|
| `use_mlp` | Enable/disable MLP-style score |
| `use_gnn` | Enable/disable GNN-style score |
| `use_rl` | Enable/disable RL-style score |
| `use_congestion` | Enable/disable congestion penalties |
| `use_fault` | Enable/disable fault-awareness |

These switches are used to implement the ablation experiments.

---

# 38. AICOF Fusion Score

For every candidate next-hop `v`, the integrated score starts at zero.

### MLP contribution

```text
+ 0.75 × MLP score
```

### GNN contribution

```text
+ 1.10 × GNN score
```

### RL contribution

```text
+ 0.85 × RL score
```

### Destination contribution

```text
+ 0.45 × 1/(1 + distance)
```

### Congestion contribution

When enabled:

```text
- 1.10 × normalized queue
- 0.85 × normalized link load
- 0.60 × normalized two-hop congestion
```

### Fault-awareness contribution

When enabled:

```text
- 1.15 × fault penalty
+ 0.80 × neighbor resilience
```

### Visited-node penalty

```text
- 0.35
```

if the candidate has already been visited.

The candidate with the highest final score is selected.

---

# 39. `build_policy()`

```python
build_policy(name, G, cfg, rng=None)
```

## Purpose

Central routing-policy factory.

Supported policy names:

```text
shortest_path
static_adaptive
mlp
gnn
rl
aicof
aicof_no_rl
aicof_no_gnn
aicof_no_mlp
aicof_no_congestion
aicof_no_fault
```

Example:

```python
policy = build_policy(
    "aicof",
    G,
    CFG,
    rng
)
```

---

# 40. AICOF Ablation Variants

The source defines six AICOF configurations:

| Model Variant | Disabled Component |
|---|---|
| `AICOF-Full` | None |
| `AICOF w/o RL` | RL component |
| `AICOF w/o GNN` | GNN component |
| `AICOF w/o MLP` | MLP component |
| `AICOF w/o Congestion` | Congestion component |
| `AICOF w/o Fault-Awareness` | Fault-awareness component |

These variants are used by:

```python
run_ablation()
```

---

# 41. `simulator.py`

This module performs packet-level routing simulation.

---

# 42. `METHOD_LOAD`

The source defines:

```python
METHOD_LOAD = {
    "shortest_path": (1.00, 1.00),
    "static_adaptive": (1.04, 1.02),
    "mlp": (0.95, 0.94),
    "gnn": (0.92, 0.90),
    "rl": (0.88, 0.86),
    "aicof": (0.84, 0.82),
    ...
}
```

Each tuple contains:

```text
(latency scale, energy scale)
```

For example:

```text
AICOF:
latency scale = 0.84
energy scale  = 0.82
```

These values directly influence simulated latency and energy.

### Scientific interpretation

These are manually assigned simulation parameters, not learned values.

---

# 43. `METHOD_FAIL_PENALTY`

This dictionary defines method-specific failure scaling.

Examples:

```text
shortest_path → 1.00
MLP           → 0.95
GNN           → 0.90
RL            → 0.87
AICOF         → 0.82
```

The effective failure ratio is:

```text
effective failure ratio =
requested failure ratio × method failure factor
```

For example, with:

```text
requested ratio = 0.08
AICOF factor = 0.82
```

the effective ratio becomes:

```text
0.08 × 0.82 = 0.0656
```

### Important comparison consideration

Because the effective failure ratio differs by method, the methods are not exposed to exactly the same number of failed edges.

For a strict controlled comparison, the same failure realization should ideally be applied to all methods.

---

# 44. `apply_failures()`

```python
apply_failures(
    G,
    failure_ratio,
    rng
)
```

## Purpose

Injects random edge failures into a graph.

### Processing

1. Copy the graph.
2. Obtain all edges.
3. Calculate number of failed edges.
4. Randomly select edges.
5. Remove them.
6. Identify isolated nodes.

### Returns

```python
H, failed_nodes
```

where:

```text
H             → graph after failures
failed_nodes  → nodes whose degree becomes zero
```

---

# 45. `simulate_routing()`

```python
simulate_routing(
    G,
    cfg,
    policy_name,
    failure_ratio=0.0,
    seed=42
)
```

## Purpose

Main packet-level simulation function.

It performs:

```text
failure injection
       ↓
policy creation
       ↓
traffic generation
       ↓
packet routing
       ↓
queue/load tracking
       ↓
latency calculation
       ↓
energy calculation
       ↓
PDR calculation
       ↓
throughput calculation
       ↓
connectivity calculation
       ↓
fault recovery calculation
```

---

# 46. Packet Routing Process

For each source-destination pair:

```text
source
  ↓
current node
  ↓
policy.choose_next_hop()
  ↓
next node
  ↓
update queue
  ↓
update link load
  ↓
calculate latency
  ↓
calculate energy
  ↓
repeat
```

Routing stops when:

```text
destination reached
```

or:

```text
maximum steps reached
```

or:

```text
no next hop
```

or:

```text
routing loop detected
```

---

# 47. `simulate_routing()` Output

Returns:

```python
{
    "connectivity_ratio": ...,
    "throughput": ...,
    "latency": ...,
    "pdr": ...,
    "energy_per_packet": ...,
    "fault_recovery_score": ...
}
```

---

# 48. Connectivity Ratio

Calculated using:

```python
connectivity_ratio(H)
```

Formula:

```text
largest connected component
--------------------------------
total network nodes
```

Higher is better.

---

# 49. Throughput

The supplied source calculates:

```text
throughput =
delivered packets / max_steps_per_packet
```

This is a simulation-defined throughput proxy.

It is not explicitly:

```text
packets/second
Gbps
bits/second
```

because the simulator does not model physical elapsed time.

---

# 50. Latency

For each successful hop:

```text
hop latency =
latency scale ×
(
    1
    + 0.022 × queue length
    + 0.012 × link load
)
```

The final average is:

```text
total latency / delivered packets
```

Lower is better.

---

# 51. Packet Delivery Ratio

The simulator calculates:

```text
PDR =
delivered packets / generated packets
```

and reports:

```text
PDR (%) = 100 × PDR
```

Higher is better.

---

# 52. Energy per Packet

For each hop:

```text
hop energy =
energy scale ×
(
    0.55
    + 0.008 × degree(current node)
    + 0.004 × hop queue
)
```

Final value:

```text
total energy / delivered packets
```

Lower is better.

---

# 53. Fault Recovery Score

The source calculates:

```text
FRS =
100 ×
(
    0.55 × PDR_fraction
    +
    0.45 × connectivity_ratio
)
```

Higher is better.

---

# 54. `experiments.py`

This module connects the simulation engine to the six manuscript-level experiments.

---

# 55. `TOPOLOGIES`

```python
TOPOLOGIES = [
    "hypercube",
    "torus",
    "fat-tree",
    "dragonfly",
    "pdn"
]
```

These are used in all topology-based experiments.

---

# 56. `AI_METHODS`

```python
AI_METHODS = [
    "shortest_path",
    "static_adaptive",
    "mlp",
    "gnn",
    "rl",
    "aicof"
]
```

These are compared in the AI-vs-traditional experiment.

---

# 57. `ABLATION_MAP`

```python
ABLATION_MAP = [
    ("AICOF-Full", "aicof"),
    ("AICOF w/o RL", "aicof_no_rl"),
    ("AICOF w/o GNN", "aicof_no_gnn"),
    ("AICOF w/o MLP", "aicof_no_mlp"),
    ("AICOF w/o Congestion", "aicof_no_congestion"),
    ("AICOF w/o Fault-Awareness", "aicof_no_fault")
]
```

This maps manuscript labels to internal policy names.

---

# 58. `avg_dict()`

```python
avg_dict(dicts)
```

## Purpose

Averages numerical simulation metrics across repeated runs.

For each metric:

```text
mean = average of non-None values
```

The result is rounded to four decimal places.

This function is used throughout the experiment functions.

---

# 59. `_sim_task()`

```python
_sim_task(task)
```

## Purpose

Executes one simulation task.

Task format:

```python
(
    topology,
    requested_node_count,
    method,
    failure_ratio,
    repetition
)
```

The function:

1. Resolves a valid topology size.
2. Builds the topology.
3. Runs `simulate_routing()`.
4. Uses:

```text
CFG.random_seed + repetition
```

as the random seed.

Returns:

```text
topology
actual node count
simulation result
```

---

# 60. `run_structural_table()`

```python
run_structural_table(node_count=64)
```

## Purpose

Generates structural characteristics for all five topologies.

Default requested size:

```text
64
```

Metrics:

```text
Node Degree
Diameter
Avg. Path Length
Path Diversity
Scalability
Fault Tolerance
```

### Output columns

```text
Topology
Nodes Used
Node Degree
Diameter
Avg. Path Length
Path Diversity
Scalability
Fault Tolerance
```

---

# 61. `run_baseline_table()`

```python
run_baseline_table(
    node_count=64,
    workers=1
)
```

## Purpose

Evaluates traditional shortest-path routing.

Failure ratio:

```text
CFG.failure_ratio_baseline
```

Default:

```text
5%
```

Metrics:

```text
Connectivity Ratio
Throughput
Avg. Latency
PDR (%)
Energy / Packet
Fault Recovery Score
```

---

# 62. `run_scalability_tables()`

```python
run_scalability_tables(workers=1)
```

## Purpose

Studies how traditional shortest-path performance changes with network size.

Default sizes:

```text
64
128
256
512
```

Failure ratio:

```text
CFG.failure_ratio_scalability
```

Default:

```text
2%
```

### Returns

Two DataFrames:

```python
latency_dataframe
throughput_dataframe
```

---

# 63. `run_ai_vs_traditional()`

```python
run_ai_vs_traditional(
    node_count=256,
    workers=1
)
```

## Purpose

Compares all six routing methods across all five topologies.

Methods:

```text
Shortest Path
Static Adaptive
MLP
GNN
RL
AICOF
```

Default requested node count:

```text
256
```

Failure ratio:

```text
CFG.failure_ratio_ai = 0.08
```

or:

```text
8%
```

### Metrics

```text
Connectivity Ratio
Throughput
Avg. Latency
PDR (%)
Energy / Packet
Fault Recovery Score
```

---

# 64. `run_aicof_gain()`

```python
run_aicof_gain(
    node_count=256,
    workers=1
)
```

## Purpose

Measures AICOF improvement over shortest-path routing for each topology.

For higher-is-better metrics:

```text
Gain (%) =
100 × (AICOF - baseline) / baseline
```

For lower-is-better metrics:

```text
Gain (%) =
100 × (baseline - AICOF) / baseline
```

The inverse formula is used for:

```text
Latency
Energy
```

### Output metrics

```text
Δ Connectivity (%)
Δ Throughput (%)
Δ Latency (%)
Δ PDR (%)
Δ Energy (%)
Δ Fault Recovery (%)
```

---

# 65. `run_ablation()`

```python
run_ablation(
    node_count=256,
    workers=1
)
```

## Purpose

Measures the contribution of individual AICOF components.

Variants:

```text
AICOF-Full
AICOF w/o RL
AICOF w/o GNN
AICOF w/o MLP
AICOF w/o Congestion
AICOF w/o Fault-Awareness
```

Metrics:

```text
Connectivity Ratio
Throughput
Avg. Latency
PDR (%)
Energy / Packet
Fault Recovery Score
```

---

# 66. `parallel.py`

## `run_parallel()`

```python
run_parallel(
    func,
    tasks,
    workers=1
)
```

## Purpose

Runs experiment tasks sequentially or using multiprocessing.

If:

```text
workers <= 1
```

it executes:

```python
[func(t) for t in tasks]
```

If:

```text
workers > 1
```

it creates:

```python
multiprocessing.Pool
```

and executes:

```python
pool.map(func, tasks)
```

---

# 67. `latex_export.py`

## `df_to_latex_table()`

```python
df_to_latex_table(
    df,
    caption,
    label,
    outpath
)
```

## Purpose

Converts a pandas DataFrame into an IEEE-style LaTeX table.

The generated structure is:

```latex
\begin{table*}[t]
\centering
\caption{...}
\label{...}
\begin{tabular}{...}
...
\end{tabular}
\end{table*}
```

---

## 67.1 Numeric formatting

Floating-point values are formatted to four decimal places and trailing zeros are removed.

Missing values become:

```text
--
```

---

# 68. `utils.py`

## `log()`

```python
log(msg)
```

Prints an immediate console message.

Example:

```python
log("[START] experiment")
```

---

## `StageTimer`

```python
with StageTimer("Experiment"):
    ...
```

Measures execution time for an experiment stage.

Successful output:

```text
[DONE ] Experiment in 5.2 sec
```

Failed output:

```text
[FAIL ] Experiment after 5.2 sec: error
```

---

## `ensure_dir()`

```python
ensure_dir(path)
```

Creates a directory if it does not already exist.

Used by `run_all.py` to create:

```text
results/
```

---

# 69. `run_all.py`

This is the main entry point.

Run:

```bash
python run_all.py
```

---

# 70. Command-Line Arguments

## `--quick`

```bash
python run_all.py --quick
```

Sets:

```text
repetitions = 4
packets_per_run = 500
max_steps_per_packet = 32
```

---

## `--workers`

```bash
python run_all.py --workers 4
```

Sets the multiprocessing worker count.

---

# 71. `save_with_latex()`

```python
save_with_latex(
    df,
    csv_path,
    tex_path,
    caption,
    label
)
```

## Purpose

Saves a DataFrame in two formats:

```text
CSV
LaTeX
```

Internally:

```python
df.to_csv(...)
df_to_latex_table(...)
```

This ensures that every experiment produces both machine-readable data and manuscript-ready LaTeX.

---

# 72. `main()`

```python
main()
```

## Purpose

Executes the complete six-stage experiment pipeline.

---

# 73. Experiment Stage 1 — Structural Analysis

```python
run_structural_table(node_count=64)
```

Generated files:

```text
results/topology_structural.csv
results/table_topology_structural.tex
```

---

# 74. Experiment Stage 2 — Traditional Baseline

```python
run_baseline_table(
    node_count=64,
    workers=args.workers
)
```

Generated files:

```text
results/baseline_traditional.csv
results/table_baseline_traditional.tex
```

---

# 75. Experiment Stage 3 — Scalability

```python
run_scalability_tables(
    workers=args.workers
)
```

Generated files:

```text
results/scalability_latency.csv
results/table_scalability_latency.tex

results/scalability_throughput.csv
results/table_scalability_throughput.tex
```

---

# 76. Experiment Stage 4 — AI vs Traditional

```python
run_ai_vs_traditional(
    node_count=256,
    workers=args.workers
)
```

Generated files:

```text
results/ai_vs_traditional.csv
results/table_ai_vs_traditional.tex
```

---

# 77. Experiment Stage 5 — AICOF Gain

```python
run_aicof_gain(
    node_count=256,
    workers=args.workers
)
```

Generated files:

```text
results/aicof_gain.csv
results/table_aicof_gain.tex
```

---

# 78. Experiment Stage 6 — Ablation

```python
run_ablation(
    node_count=256,
    workers=args.workers
)
```

Generated files:

```text
results/ablation.csv
results/table_ablation.tex
```

---

# 79. Complete Output Directory

After a successful run:

```text
results/
│
├── topology_structural.csv
├── table_topology_structural.tex
│
├── baseline_traditional.csv
├── table_baseline_traditional.tex
│
├── scalability_latency.csv
├── table_scalability_latency.tex
│
├── scalability_throughput.csv
├── table_scalability_throughput.tex
│
├── ai_vs_traditional.csv
├── table_ai_vs_traditional.tex
│
├── aicof_gain.csv
├── table_aicof_gain.tex
│
├── ablation.csv
└── table_ablation.tex
```

---

# 80. Function-to-Module Reference

| Function / Class | Module | Main Purpose |
|---|---|---|
| `ExperimentConfig` | `config.py` | Global experiment settings |
| `CFG` | `config.py` | Configuration instance |
| `build_hypercube()` | `topologies.py` | Generate hypercube |
| `build_torus()` | `topologies.py` | Generate torus |
| `build_fat_tree()` | `topologies.py` | Generate balanced-tree/fat-tree approximation |
| `build_dragonfly()` | `topologies.py` | Generate Dragonfly-like network |
| `build_pdn()` | `topologies.py` | Generate PDN |
| `nearest_power_of_two()` | `topologies.py` | Validate/adjust hypercube size |
| `nearest_perfect_square()` | `topologies.py` | Validate/adjust torus size |
| `resolve_valid_size()` | `topologies.py` | Select topology-compatible size |
| `get_topology()` | `topologies.py` | Topology factory |
| `sample_packet_pairs()` | `traffic.py` | Generate traffic |
| `safe_average_shortest_path_length()` | `metrics.py` | Calculate average path length |
| `structural_metrics()` | `metrics.py` | Calculate structural metrics |
| `connectivity_ratio()` | `metrics.py` | Calculate connectivity |
| `_safe_norm()` | `routing.py` | Normalize a feature |
| `RoutingPolicy` | `routing.py` | Base routing class |
| `dist()` | `routing.py` | Calculate path distance |
| `local_fault_penalty()` | `routing.py` | Fault indicator |
| `neighbor_resilience()` | `routing.py` | Degree-based resilience |
| `two_hop_congestion()` | `routing.py` | Local congestion estimate |
| `ShortestPathPolicy` | `routing.py` | Traditional shortest-path routing |
| `StaticAdaptivePolicy` | `routing.py` | Static adaptive routing |
| `MLPPolicy` | `routing.py` | MLP-style scoring |
| `GNNPolicy` | `routing.py` | GNN-style graph scoring |
| `RLPolicy` | `routing.py` | RL-style adaptive scoring |
| `AICOFPolicy` | `routing.py` | Integrated AICOF routing |
| `build_policy()` | `routing.py` | Routing-policy factory |
| `apply_failures()` | `simulator.py` | Inject edge failures |
| `simulate_routing()` | `simulator.py` | Execute packet simulation |
| `avg_dict()` | `experiments.py` | Average repeated results |
| `_sim_task()` | `experiments.py` | Execute one simulation |
| `run_structural_table()` | `experiments.py` | Structural experiment |
| `run_baseline_table()` | `experiments.py` | Traditional baseline |
| `run_scalability_tables()` | `experiments.py` | Scalability study |
| `run_ai_vs_traditional()` | `experiments.py` | AI comparison |
| `run_aicof_gain()` | `experiments.py` | AICOF improvement |
| `run_ablation()` | `experiments.py` | Ablation study |
| `run_parallel()` | `parallel.py` | Parallel execution |
| `df_to_latex_table()` | `latex_export.py` | DataFrame to LaTeX |
| `log()` | `utils.py` | Console logging |
| `StageTimer` | `utils.py` | Stage timing |
| `ensure_dir()` | `utils.py` | Create output directory |
| `save_with_latex()` | `run_all.py` | Save CSV + LaTeX |
| `main()` | `run_all.py` | Run all experiments |

---

# 81. Experiment-to-Paper Mapping

| Experiment | Function | Requested Size | Failure Ratio |
|---|---|---:|---:|
| Structural topology analysis | `run_structural_table()` | 64 | N/A |
| Traditional baseline | `run_baseline_table()` | 64 | 5% |
| Scalability | `run_scalability_tables()` | 64–512 | 2% |
| AI vs traditional | `run_ai_vs_traditional()` | 256 | 8% |
| AICOF gain | `run_aicof_gain()` | 256 | 8% |
| Ablation | `run_ablation()` | 256 | 8% |

---

# 82. V5 Configuration Summary

The default full-run configuration is:

```text
Node sizes:
64, 128, 256, 512

Repetitions:
12

Packets per run:
1800

Maximum steps per packet:
56

Traffic:
uniform

Hotspot fraction:
0.22

Baseline failure ratio:
5%

Scalability failure ratio:
2%

AI comparison failure ratio:
8%

Random seed:
42
```

---

# 83. Reproducibility

The base random seed is:

```python
CFG.random_seed = 42
```

Each repetition uses:

```python
CFG.random_seed + rep
```

Therefore repeated runs can be deterministic when the following are kept unchanged:

```text
Python version
NetworkX version
NumPy version
Pandas version
source code
configuration
random seed
```

For publication reproducibility, archive:

```text
source code
requirements.txt
configuration
random seed
generated CSV files
generated LaTeX tables
figure-generation code
```

---

# 84. Important Scientific Modeling Notes

## 84.1 AI components are score-based

The current V5 implementation uses fixed mathematical coefficients.

There is no model training.

Therefore:

```text
MLPPolicy ≠ trained MLP
GNNPolicy ≠ trained GNN
RLPolicy  ≠ trained PPO/RL agent
```

This should be reflected accurately in the manuscript.

---

## 84.2 Method-specific failure behavior

`METHOD_FAIL_PENALTY` makes the effective failure ratio method-dependent.

For example:

```text
Shortest Path → 1.00
AICOF         → 0.82
```

Thus AICOF may experience fewer failed edges than shortest-path routing under the same requested failure ratio.

For rigorous experimental comparison, it is preferable to use identical failure sets across methods.

---

## 84.3 Method-specific latency and energy scaling

`METHOD_LOAD` assigns each method its own latency and energy scale.

Therefore some performance separation is deliberately encoded in the simulator.

These parameters should be disclosed in the methodology if the results are used in a publication.

---

## 84.4 Throughput is a proxy

The current formula is:

```text
delivered packets / max_steps_per_packet
```

It is not a direct physical throughput measurement.

---

## 84.5 Energy is a simulated metric

Energy is modeled from:

```text
method energy scale
node degree
queue length
```

It is not measured from physical hardware.

---

## 84.6 Path diversity is a proxy

The source defines:

```text
path diversity =
network density × average degree
```

It should not be described as the number of independent paths.

---

## 84.7 Scalability is a structural proxy

The source defines:

```text
scalability =
1 / average path length
```

This is an indicator rather than a direct runtime scalability measurement.

---

# 85. Recommended Execution Workflow

Use the following sequence:

```text
1. Install dependencies
        ↓
2. Run quick validation
        ↓
3. Inspect generated CSV files
        ↓
4. Run full simulation
        ↓
5. Archive CSV results
        ↓
6. Generate figures
        ↓
7. Use generated LaTeX tables
        ↓
8. Update manuscript
        ↓
9. Verify every reported number
        ↓
10. Archive source + configuration + results
```

---

# 86. Recommended First Run

Start with:

```bash
python run_all.py --quick --workers 1
```

If successful:

```bash
python run_all.py --quick --workers 2
```

Then perform the full run:

```bash
python run_all.py --workers 2
```

If the machine has sufficient CPU and memory:

```bash
python run_all.py --workers 4
```

---

# 87. Manual Single-Topology Test

A single AICOF simulation can be tested with:

```python
from config import CFG
from topologies import get_topology
from simulator import simulate_routing

G = get_topology("hypercube", 64)

result = simulate_routing(
    G,
    CFG,
    "aicof",
    failure_ratio=0.08,
    seed=42
)

print(result)
```

This is useful before running the complete six-experiment pipeline.

---

# 88. Manual Routing Comparison

```python
methods = [
    "shortest_path",
    "static_adaptive",
    "mlp",
    "gnn",
    "rl",
    "aicof"
]

for method in methods:
    result = simulate_routing(
        G,
        CFG,
        method,
        failure_ratio=0.08,
        seed=42
    )
    print(method, result)
```

This compares all routing strategies on one network.

---

# 89. Manual Ablation Test

```python
methods = [
    "aicof",
    "aicof_no_rl",
    "aicof_no_gnn",
    "aicof_no_mlp",
    "aicof_no_congestion",
    "aicof_no_fault"
]

for method in methods:
    result = simulate_routing(
        G,
        CFG,
        method,
        failure_ratio=0.08,
        seed=42
    )
    print(method, result)
```

This is useful for checking the individual AICOF components.

---

# 90. Troubleshooting

## `ModuleNotFoundError`

Install the dependencies:

```bash
python -m pip install -r requirements.txt
```

---

## Hypercube size error

Use a power-of-two size such as:

```text
64
128
256
512
```

---

## Torus size error

Use a perfect-square size such as:

```text
64
100
144
196
256
324
400
484
576
```

---

## Simulation is slow

Start with:

```bash
python run_all.py --quick --workers 1
```

Then increase workers:

```bash
python run_all.py --quick --workers 2
```

or:

```bash
python run_all.py --quick --workers 4
```

---

# 91. Numerical Source-of-Truth Rule

Do not manually enter previous manuscript values into the paper after changing the simulation.

Use:

```text
Python simulation
       ↓
generated CSV
       ↓
generated LaTeX table / figures
       ↓
manuscript
```

The generated CSV files should be treated as the numerical source of truth for the final manuscript.

Important result files to preserve include:

```text
results/ai_vs_traditional.csv
results/aicof_gain.csv
results/ablation.csv
results/baseline_traditional.csv
```

---

# 92. V5 File-to-Function Map

```text
config.py
    └── ExperimentConfig
    └── CFG

topologies.py
    ├── build_hypercube
    ├── build_torus
    ├── build_fat_tree
    ├── build_dragonfly
    ├── build_pdn
    ├── nearest_power_of_two
    ├── nearest_perfect_square
    ├── resolve_valid_size
    └── get_topology

traffic.py
    └── sample_packet_pairs

metrics.py
    ├── safe_average_shortest_path_length
    ├── structural_metrics
    └── connectivity_ratio

routing.py
    ├── _safe_norm
    ├── RoutingPolicy
    ├── ShortestPathPolicy
    ├── StaticAdaptivePolicy
    ├── MLPPolicy
    ├── GNNPolicy
    ├── RLPolicy
    ├── AICOFPolicy
    └── build_policy

simulator.py
    ├── METHOD_LOAD
    ├── METHOD_FAIL_PENALTY
    ├── apply_failures
    └── simulate_routing

experiments.py
    ├── TOPOLOGIES
    ├── AI_METHODS
    ├── ABLATION_MAP
    ├── avg_dict
    ├── _sim_task
    ├── run_structural_table
    ├── run_baseline_table
    ├── run_scalability_tables
    ├── run_ai_vs_traditional
    ├── run_aicof_gain
    └── run_ablation

parallel.py
    └── run_parallel

latex_export.py
    └── df_to_latex_table

utils.py
    ├── log
    ├── StageTimer
    └── ensure_dir

run_all.py
    ├── save_with_latex
    └── main
```

---

# 93. V5 Summary

The supplied V5 package implements a six-stage experimental pipeline:

```text
                 AICOF V5
                    |
       +------------+------------+
       |            |            |
    Topology      Traffic      Failures
       |            |            |
       +------------+------------+
                    |
                    v
             Routing Policies
                    |
       +------------+------------+
       |      |      |      |    |
      SP     SA    MLP    GNN   RL
                    \      |    /
                     \     |   /
                      \    |  /
                       AICOF
                         |
                         v
                    Packet Metrics
                         |
             +-----------+-----------+
             |           |           |
         Structural   Performance   Ablation
             |           |           |
             +-----------+-----------+
                         |
                         v
                   CSV + LaTeX
```

The six manuscript-level analyses are:

```text
1. Structural topology analysis
2. Traditional baseline routing
3. Scalability
4. AI vs traditional routing
5. AICOF gain analysis
6. AICOF ablation study
```

The key integrated AICOF mechanism combines:

```text
MLP-style local features
+
GNN-style graph features
+
RL-style adaptive score
+
congestion awareness
+
fault awareness
```

For scientific reporting, the current V5 source should be described according to what is actually implemented: **fixed-weight AI-inspired routing policies and an integrated AICOF score-based routing framework**, rather than trained MLP/GNN/PPO models.
