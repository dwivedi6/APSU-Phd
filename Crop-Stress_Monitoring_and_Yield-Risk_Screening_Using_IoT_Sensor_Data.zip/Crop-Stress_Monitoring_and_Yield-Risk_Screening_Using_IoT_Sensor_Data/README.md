# Computational Intelligence for Real-Time Crop Stress Monitoring and Yield-Risk Screening Using IoT Sensor Data

## Submission Package

This package contains the revised 15–20 page book-chapter manuscript prepared for the edited volume **Computational Intelligence in Agriculture: Frameworks, Models, and Applications for Sustainability**.

### Main files
- `main.tex` — LaTeX manuscript source
- `Computational_Intelligence_Agriculture_15_20_Page_Revised.pdf` — compiled manuscript
- `references.bib` — bibliography source
- `aicof_agri_simulation.py` — reproducible Python experiment
- `synthetic_agri_sensor_data.csv` — synthetic benchmark data
- `model_results.csv` — model comparison results
- `cross_validation_results.csv` — five-fold validation results
- `ablation_results.csv` — feature-group ablation results
- `ambiguous_cases.csv` — borderline prediction cases
- `figures/` — manuscript figures

## Important scientific scope

The experimental dataset is synthetic and is disclosed as such in the manuscript. The reported model results demonstrate computational reproducibility and pipeline behavior; they are **not presented as field validation or direct proof of agricultural yield prediction**.

For real deployment, the synthetic generator should be replaced with calibrated IoT observations and field-level ground truth collected across seasons, locations and crop stages.

## Models
- Logistic Regression
- Random Forest
- Gradient Boosting
- Multilayer Perceptron (MLP)

## Main analyses
- Hold-out evaluation
- Five-fold cross-validation
- Feature-group ablation
- Feature importance
- Confusion matrix
- Probability-threshold sensitivity
- Real-time IoT architecture
- Remote-sensing and computer-vision extension
- Field-validation protocol

## Reproducibility

The manuscript's synthetic data-generation mechanism is explicitly defined in the mathematical formulation and implemented in the supplied Python script.
