"""
Reproducible computational-intelligence agriculture benchmark.
Synthetic data are intentionally used so that no field measurements are invented.
Replace the generator with calibrated/public field data for empirical publication.
"""
import numpy as np, pandas as pd
from sklearn.model_selection import train_test_split, StratifiedKFold, cross_validate
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.linear_model import LogisticRegression

SEED=42
rng=np.random.default_rng(SEED)
N=2400
C=np.clip

soil_moisture=C(rng.normal(28,9,N),5,55)
temperature=C(rng.normal(29,5,N),15,45)
humidity=C(rng.normal(63,14,N),20,95)
soil_ph=C(rng.normal(6.7,.55,N),4.8,8.2)
rainfall_7d=C(rng.gamma(2.2,10,N),0,90)
ndvi=C(rng.normal(.63,.16,N),.10,.95)
nitrogen=C(rng.normal(72,25,N),15,150)
phosphorus=C(rng.normal(42,15,N),8,90)
potassium=C(rng.normal(120,35,N),25,220)
solar=C(rng.normal(19,4.5,N),7,30)
leaf_wetness=C(rng.normal(.38,.18,N),0,1)

W=np.maximum(0,22-soil_moisture)/22
H=np.maximum(0,temperature-34)/10
U=np.maximum(0,humidity-82)/18
N1=np.maximum(0,60-nitrogen)/60
D=np.maximum(0,.58-ndvi)/.58
R=np.maximum(0,18-rainfall_7d)/18
P=np.abs(soil_ph-6.6)/1.8
L=np.maximum(0,leaf_wetness-.65)/.35
S=1.55*W+1.20*H+.75*U+.75*N1+1.25*D+.60*R+.35*P+.45*L+rng.normal(0,.10,N)

threshold=np.quantile(S,.60)
y=(S>=threshold).astype(int)

df=pd.DataFrame({
'soil_moisture_pct':soil_moisture,'temperature_c':temperature,
'humidity_pct':humidity,'soil_ph':soil_ph,'rainfall_7d_mm':rainfall_7d,
'ndvi':ndvi,'nitrogen_mgkg':nitrogen,'phosphorus_mgkg':phosphorus,
'potassium_mgkg':potassium,'solar_radiation_mj_m2':solar,
'leaf_wetness':leaf_wetness,'stress_risk':y})
df.to_csv('synthetic_agri_sensor_data.csv',index=False)

X=df.drop(columns='stress_risk'); Y=df.stress_risk
Xtr,Xte,ytr,yte=train_test_split(X,Y,test_size=.25,stratify=Y,random_state=SEED)

models={
'Logistic Regression':Pipeline([('scaler',StandardScaler()),('model',LogisticRegression(max_iter=1500,random_state=SEED))]),
'Random Forest':RandomForestClassifier(n_estimators=300,max_depth=10,min_samples_leaf=3,random_state=SEED,n_jobs=-1),
'Gradient Boosting':GradientBoostingClassifier(n_estimators=180,learning_rate=.05,max_depth=3,random_state=SEED),
'MLP Neural Network':Pipeline([('scaler',StandardScaler()),('model',MLPClassifier(hidden_layer_sizes=(32,16),early_stopping=True,max_iter=700,random_state=SEED))])
}
for name,m in models.items():
    m.fit(Xtr,ytr); pred=m.predict(Xte); prob=m.predict_proba(Xte)[:,1]
    print(name)
    print(' Accuracy=',round(accuracy_score(yte,pred),4),
          ' Precision=',round(precision_score(yte,pred),4),
          ' Recall=',round(recall_score(yte,pred),4),
          ' F1=',round(f1_score(yte,pred),4),
          ' ROC-AUC=',round(roc_auc_score(yte,prob),4))
