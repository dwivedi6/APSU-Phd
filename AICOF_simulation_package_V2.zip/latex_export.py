from pathlib import Path
import pandas as pd

def df_to_latex_table(df, caption, label, outpath):
    cols = list(df.columns)
    colspec = "l" + "c" * (len(cols) - 1)
    def fmt(x):
        if pd.isna(x):
            return "--"
        if isinstance(x, float):
            return f"{x:.4f}".rstrip("0").rstrip(".")
        return str(x)
    lines = []
    lines.append(r"\begin{table*}[t]")
    lines.append(r"\centering")
    lines.append(rf"\caption{{{caption}}}")
    lines.append(rf"\label{{{label}}}")
    lines.append(rf"\begin{{tabular}}{{{colspec}}}")
    lines.append(r"\hline")
    lines.append(" & ".join(cols) + r" \\")
    lines.append(r"\hline")
    for _, row in df.iterrows():
        vals = [fmt(row[c]) for c in cols]
        lines.append(" & ".join(vals) + r" \\")
    lines.append(r"\hline")
    lines.append(r"\end{tabular}")
    lines.append(r"\end{table*}")
    Path(outpath).write_text("\n".join(lines), encoding="utf-8")
