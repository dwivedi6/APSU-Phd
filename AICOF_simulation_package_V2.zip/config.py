from dataclasses import dataclass, field

@dataclass
class ExperimentConfig:
    node_sizes: list = field(default_factory=lambda: [64, 128, 256, 512])
    repetitions: int = 30
    packets_per_run: int = 2000
    max_steps_per_packet: int = 64
    traffic_pattern: str = "uniform"
    hotspot_fraction: float = 0.20
    failure_ratios: list = field(default_factory=lambda: [0.0, 0.02, 0.05, 0.10])
    random_seed: int = 42

    queue_penalty: float = 0.40
    load_penalty: float = 0.25
    revisit_penalty: float = 4.0

    w_distance: float = 3.2
    w_progress: float = 3.8
    w_queue: float = 1.1
    w_load: float = 0.9
    w_reliability: float = 1.0
    w_diversity: float = 0.7
    w_degree: float = 0.3

    aicof_mlp_weight: float = 0.20
    aicof_gnn_weight: float = 0.20
    aicof_rl_weight: float = 0.10
    aicof_base_weight: float = 0.50

    rl_alpha: float = 0.20
    rl_gamma: float = 0.90
    rl_epsilon_train: float = 0.15
    rl_epsilon_eval: float = 0.00
    rl_pretrain_episodes: int = 4

CFG = ExperimentConfig()
