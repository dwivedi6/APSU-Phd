import math
import networkx as nx

def build_hypercube(n):
    dim = int(math.log2(n))
    if 2 ** dim != n:
        raise ValueError("Hypercube requires power-of-2 size.")
    return nx.convert_node_labels_to_integers(nx.hypercube_graph(dim))

def build_torus(n):
    side = int(math.sqrt(n))
    if side * side != n:
        raise ValueError("Torus requires perfect-square size.")
    G = nx.grid_2d_graph(side, side, periodic=True)
    return nx.convert_node_labels_to_integers(G)

def build_fat_tree(n):
    depth = max(2, int(round(math.log2(max(n, 2)))) // 2)
    r = 4
    G = nx.balanced_tree(r, depth)
    if G.number_of_nodes() > n:
        keep = list(G.nodes())[:n]
        G = G.subgraph(keep).copy()
    return nx.convert_node_labels_to_integers(G)

def build_dragonfly(n):
    gsize = max(4, int(round(n ** 0.5)))
    groups = max(2, (n + gsize - 1) // gsize)
    G = nx.Graph()
    node = 0
    group_nodes = []
    for _ in range(groups):
        group = []
        for _ in range(gsize):
            if node >= n:
                break
            G.add_node(node)
            group.append(node)
            node += 1
        group_nodes.append(group)
        for i in range(len(group)):
            for j in range(i + 1, len(group)):
                G.add_edge(group[i], group[j])
    nonempty = [g for g in group_nodes if g]
    for i in range(len(nonempty)):
        a = nonempty[i][0]
        b = nonempty[(i + 1) % len(nonempty)][0]
        G.add_edge(a, b)
        if len(nonempty) > 2:
            c = nonempty[(i + 2) % len(nonempty)][0]
            G.add_edge(a, c)
    return G

def build_pdn(n):
    G = nx.Graph()
    G.add_nodes_from(range(n))
    offsets = [1, 3, 7]
    offsets = [o for o in offsets if o < n]
    for u in range(n):
        for d in offsets:
            G.add_edge(u, (u + d) % n)
            G.add_edge(u, (u - d) % n)
    return nx.Graph(G)

def nearest_power_of_two(n):
    if n <= 1:
        return 1
    p = 1
    while p < n:
        p *= 2
    prevp = p // 2
    return prevp if prevp >= 2 and abs(prevp - n) <= abs(p - n) else p

def nearest_perfect_square(n):
    s = int(round(math.sqrt(n)))
    cands = sorted(set([max(4, (s-1)**2), max(4, s**2), max(4, (s+1)**2)]))
    return min(cands, key=lambda x: abs(x - n))

def resolve_valid_size(topology, requested_n):
    t = topology.lower()
    if t == "hypercube":
        return nearest_power_of_two(requested_n)
    if t == "torus":
        return nearest_perfect_square(requested_n)
    return requested_n

def get_topology(name, n):
    name = name.lower()
    if name == "hypercube":
        return build_hypercube(n)
    if name == "torus":
        return build_torus(n)
    if name == "fat-tree":
        return build_fat_tree(n)
    if name == "dragonfly":
        return build_dragonfly(n)
    if name == "pdn":
        return build_pdn(n)
    raise ValueError(f"Unknown topology: {name}")
