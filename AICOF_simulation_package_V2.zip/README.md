# AICOF Simulation Package V2 (Publication-Oriented)

Improved AICOF simulator for IEEE-paper tables.

## Run
```bash
pip install -r requirements.txt
python run_all.py --quick   # quick sanity run
python run_all.py           # full run
```

## Outputs
CSV + LaTeX tables in `results/`:
- topology_structural.csv
- baseline_traditional.csv
- scalability_latency.csv
- scalability_throughput.csv
- ai_vs_traditional.csv
- aicof_gain.csv
- ablation.csv
