import random
import networkx as nx
from collections import defaultdict

class RoutingPolicy:
    def __init__(self, G, cfg, rng=None):
        self.G = G
        self.cfg = cfg
        self.rng = rng or random.Random()
        if G.number_of_nodes() <= 700:
            self.betweenness = nx.betweenness_centrality(G)
        else:
            self.betweenness = {n: 0.0 for n in G.nodes()}

    def shortest_distance(self, u, dst):
        try:
            return nx.shortest_path_length(self.G, u, dst)
        except nx.NetworkXNoPath:
            return 10**9

    def reliability(self, v):
        deg = self.G.degree(v)
        return deg / max(1, max(dict(self.G.degree()).values()))

    def diversity_penalty(self, v):
        return self.betweenness.get(v, 0.0)

    def base_score(self, current, v, dst, queue_len, link_load):
        curr_dist = self.shortest_distance(current, dst)
        next_dist = self.shortest_distance(v, dst)
        progress = max(0, curr_dist - next_dist)
        q = queue_len.get(v, 0)
        load = link_load.get((current, v), 0)
        rel = self.reliability(v)
        div = self.diversity_penalty(v)
        degree = self.G.degree(v)
        score = (
            self.cfg.w_progress * progress
            - self.cfg.w_distance * next_dist
            - self.cfg.w_queue * q
            - self.cfg.w_load * load
            + self.cfg.w_reliability * rel
            - self.cfg.w_diversity * div
            + self.cfg.w_degree * degree / max(1, self.G.number_of_nodes() ** 0.5)
        )
        return score

class ShortestPathPolicy(RoutingPolicy):
    def choose_next_hop(self, current, dst, queue_len, link_load, visited=None):
        nbrs = list(self.G.neighbors(current))
        if not nbrs:
            return None
        nbrs.sort(key=lambda v: (self.shortest_distance(v, dst), queue_len.get(v, 0), link_load.get((current, v), 0)))
        return nbrs[0]

class StaticAdaptivePolicy(RoutingPolicy):
    def choose_next_hop(self, current, dst, queue_len, link_load, visited=None):
        nbrs = list(self.G.neighbors(current))
        if not nbrs:
            return None
        best, best_score = None, -1e18
        visited = visited or set()
        for v in nbrs:
            score = self.base_score(current, v, dst, queue_len, link_load)
            if v in visited:
                score -= self.cfg.revisit_penalty
            if score > best_score:
                best_score = score
                best = v
        return best

class MLPPolicy(RoutingPolicy):
    def choose_next_hop(self, current, dst, queue_len, link_load, visited=None):
        nbrs = list(self.G.neighbors(current))
        if not nbrs:
            return None
        best, best_score = None, -1e18
        visited = visited or set()
        for v in nbrs:
            score = self.base_score(current, v, dst, queue_len, link_load)
            score += 0.15 * self.G.degree(v)
            score += 0.10 * self.reliability(v)
            if v in visited:
                score -= self.cfg.revisit_penalty
            if score > best_score:
                best_score = score
                best = v
        return best

class GNNPolicy(RoutingPolicy):
    def choose_next_hop(self, current, dst, queue_len, link_load, visited=None):
        nbrs = list(self.G.neighbors(current))
        if not nbrs:
            return None
        best, best_score = None, -1e18
        visited = visited or set()
        for v in nbrs:
            vn = list(self.G.neighbors(v))
            if vn:
                avg_deg = sum(self.G.degree(x) for x in vn) / len(vn)
                avg_q = sum(queue_len.get(x, 0) for x in vn) / len(vn)
                avg_bc = sum(self.betweenness.get(x, 0.0) for x in vn) / len(vn)
            else:
                avg_deg, avg_q, avg_bc = 0.0, 0.0, 0.0
            score = self.base_score(current, v, dst, queue_len, link_load)
            score += 0.12 * avg_deg
            score -= 0.20 * avg_q
            score -= 0.10 * avg_bc
            if v in visited:
                score -= self.cfg.revisit_penalty
            if score > best_score:
                best_score = score
                best = v
        return best

class RLPolicy(RoutingPolicy):
    def __init__(self, G, cfg, rng=None, epsilon=None):
        super().__init__(G, cfg, rng)
        self.q = defaultdict(float)
        self.epsilon = cfg.rl_epsilon_train if epsilon is None else epsilon

    def state(self, current, dst, next_hop, queue_len, link_load):
        dist = min(self.shortest_distance(next_hop, dst), 15)
        q = min(queue_len.get(next_hop, 0), 9)
        load = min(link_load.get((current, next_hop), 0), 9)
        progress = min(max(0, self.shortest_distance(current, dst) - self.shortest_distance(next_hop, dst)), 5)
        return (dist, q, load, progress)

    def choose_next_hop(self, current, dst, queue_len, link_load, visited=None):
        nbrs = list(self.G.neighbors(current))
        if not nbrs:
            return None
        visited = visited or set()
        if self.rng.random() < self.epsilon:
            candidates = [v for v in nbrs if v not in visited] or nbrs
            return self.rng.choice(candidates)
        best, best_score = None, -1e18
        for v in nbrs:
            s = self.state(current, dst, v, queue_len, link_load)
            score = self.base_score(current, v, dst, queue_len, link_load) + self.q[(current, s)]
            if v in visited:
                score -= self.cfg.revisit_penalty
            if score > best_score:
                best_score = score
                best = v
        return best

    def update(self, current, dst, next_hop, reward, queue_len, link_load):
        s = self.state(current, dst, next_hop, queue_len, link_load)
        old = self.q[(current, s)]
        self.q[(current, s)] = old + self.cfg.rl_alpha * (reward - old)

class AICOFPolicy(RoutingPolicy):
    def __init__(self, G, cfg, rng=None, variant="full"):
        super().__init__(G, cfg, rng)
        self.variant = variant
        self.rl = RLPolicy(G, cfg, rng, epsilon=cfg.rl_epsilon_eval)

    def mlp_term(self, current, v, dst, queue_len, link_load):
        return 0.15 * self.G.degree(v) + 0.10 * self.reliability(v)

    def gnn_term(self, current, v, dst, queue_len, link_load):
        vn = list(self.G.neighbors(v))
        if not vn:
            return 0.0
        avg_deg = sum(self.G.degree(x) for x in vn) / len(vn)
        avg_q = sum(queue_len.get(x, 0) for x in vn) / len(vn)
        return 0.12 * avg_deg - 0.20 * avg_q

    def choose_next_hop(self, current, dst, queue_len, link_load, visited=None):
        nbrs = list(self.G.neighbors(current))
        if not nbrs:
            return None
        visited = visited or set()
        best, best_score = None, -1e18
        for v in nbrs:
            score = self.base_score(current, v, dst, queue_len, link_load)
            if self.variant == "no_congestion":
                score += self.cfg.w_queue * queue_len.get(v, 0)
                score += self.cfg.w_load * link_load.get((current, v), 0)
            if self.variant == "no_fault":
                score -= self.cfg.w_reliability * self.reliability(v)
            if self.variant != "no_mlp":
                score += self.cfg.aicof_mlp_weight * self.mlp_term(current, v, dst, queue_len, link_load)
            if self.variant != "no_gnn":
                score += self.cfg.aicof_gnn_weight * self.gnn_term(current, v, dst, queue_len, link_load)
            if self.variant != "no_rl":
                s = self.rl.state(current, dst, v, queue_len, link_load)
                score += self.cfg.aicof_rl_weight * self.rl.q[(current, s)]
            if v in visited:
                score -= self.cfg.revisit_penalty
            if score > best_score:
                best_score = score
                best = v
        return best

    def update(self, current, dst, next_hop, reward, queue_len, link_load):
        if self.variant != "no_rl":
            self.rl.update(current, dst, next_hop, reward, queue_len, link_load)

def build_policy(name, G, cfg, rng=None):
    name = name.lower()
    if name == "shortest_path":
        return ShortestPathPolicy(G, cfg, rng)
    if name == "static_adaptive":
        return StaticAdaptivePolicy(G, cfg, rng)
    if name == "mlp":
        return MLPPolicy(G, cfg, rng)
    if name == "gnn":
        return GNNPolicy(G, cfg, rng)
    if name == "rl":
        return RLPolicy(G, cfg, rng, epsilon=cfg.rl_epsilon_eval)
    if name == "aicof":
        return AICOFPolicy(G, cfg, rng, variant="full")
    if name == "aicof_no_rl":
        return AICOFPolicy(G, cfg, rng, variant="no_rl")
    if name == "aicof_no_gnn":
        return AICOFPolicy(G, cfg, rng, variant="no_gnn")
    if name == "aicof_no_mlp":
        return AICOFPolicy(G, cfg, rng, variant="no_mlp")
    if name == "aicof_no_congestion":
        return AICOFPolicy(G, cfg, rng, variant="no_congestion")
    if name == "aicof_no_fault":
        return AICOFPolicy(G, cfg, rng, variant="no_fault")
    raise ValueError(f"Unknown policy {name}")
