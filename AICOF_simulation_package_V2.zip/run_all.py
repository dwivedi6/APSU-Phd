import argparse
from pathlib import Path

from config import CFG
from experiments import (
    run_structural_table,
    run_baseline_table,
    run_scalability_tables,
    run_ai_vs_traditional,
    run_aicof_gain,
    run_ablation,
)
from latex_export import df_to_latex_table

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--quick", action="store_true", help="Run a fast sanity-check configuration")
    args = parser.parse_args()

    if args.quick:
        CFG.repetitions = 3
        CFG.packets_per_run = 500
        CFG.max_steps_per_packet = 32
        print("[Quick mode] repetitions=3, packets_per_run=500, max_steps_per_packet=32")
    else:
        print("[Full mode] using config.py settings")

    out = Path("results")
    out.mkdir(exist_ok=True)

    print("[1/6] Topology structural table...")
    structural = run_structural_table(node_count=64)
    structural.to_csv(out / "topology_structural.csv", index=False)
    df_to_latex_table(structural, "Topology-wise structural and communication characteristics.", "tab:topology_structural", out / "table_topology_structural.tex")

    print("[2/6] Baseline traditional-routing table...")
    baseline = run_baseline_table(node_count=64)
    baseline.to_csv(out / "baseline_traditional.csv", index=False)
    df_to_latex_table(baseline, "Baseline performance of interconnection topologies under traditional shortest-path routing.", "tab:baseline_traditional", out / "table_baseline_traditional.tex")

    print("[3/6] Scalability tables...")
    scalability_latency, scalability_throughput = run_scalability_tables()
    scalability_latency.to_csv(out / "scalability_latency.csv", index=False)
    scalability_throughput.to_csv(out / "scalability_throughput.csv", index=False)
    df_to_latex_table(scalability_latency, "Scalability analysis of topologies with increasing network size (latency).", "tab:scalability_latency", out / "table_scalability_latency.tex")
    df_to_latex_table(scalability_throughput, "Scalability analysis of topologies with increasing network size (throughput).", "tab:scalability_throughput", out / "table_scalability_throughput.tex")

    print("[4/6] AI vs traditional routing...")
    ai = run_ai_vs_traditional(node_count=256)
    ai.to_csv(out / "ai_vs_traditional.csv", index=False)
    df_to_latex_table(ai, "Performance comparison between traditional routing and AI-assisted routing.", "tab:ai_vs_traditional", out / "table_ai_vs_traditional.tex")

    print("[5/6] AICOF gain table...")
    gain = run_aicof_gain(node_count=256)
    gain.to_csv(out / "aicof_gain.csv", index=False)
    df_to_latex_table(gain, "Topology-wise improvement of AICOF over traditional shortest-path routing.", "tab:aicof_gain", out / "table_aicof_gain.tex")

    print("[6/6] Ablation table...")
    ablation = run_ablation(node_count=256)
    ablation.to_csv(out / "ablation.csv", index=False)
    df_to_latex_table(ablation, "Ablation study of the proposed AICOF framework.", "tab:ablation", out / "table_ablation.tex")

    print("\nAll experiment tables generated in ./results")
    print("CSV + LaTeX tables are ready.")

if __name__ == "__main__":
    main()
