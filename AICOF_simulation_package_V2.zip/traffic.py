import random

def sample_packet_pairs(nodes, count, pattern="uniform", hotspot_fraction=0.2, rng=None):
    rng = rng or random.Random()
    nodes = list(nodes)
    N = len(nodes)
    packets = []
    if N < 2:
        return packets

    if pattern == "uniform":
        for _ in range(count):
            s = rng.choice(nodes)
            d = rng.choice(nodes)
            while d == s:
                d = rng.choice(nodes)
            packets.append((s, d))
    elif pattern == "hotspot":
        hotspot_count = max(1, int(N * hotspot_fraction))
        hotspots = nodes[:hotspot_count]
        for _ in range(count):
            s = rng.choice(nodes)
            d = rng.choice(hotspots if rng.random() < 0.6 else nodes)
            while d == s:
                d = rng.choice(nodes)
            packets.append((s, d))
    elif pattern == "transpose":
        idx = {nodes[i]: i for i in range(N)}
        for _ in range(count):
            s = rng.choice(nodes)
            d = nodes[(idx[s] + N // 2) % N]
            if d == s:
                d = rng.choice(nodes)
            packets.append((s, d))
    else:
        raise ValueError(f"Unknown traffic pattern: {pattern}")
    return packets
