import random
from collections import defaultdict

from metrics import connectivity_ratio
from traffic import sample_packet_pairs
from routing import build_policy, RLPolicy

def apply_failures(G, failure_ratio, rng):
    H = G.copy()
    if failure_ratio <= 0:
        return H
    edges = list(H.edges())
    k = int(len(edges) * failure_ratio)
    if k > 0 and edges:
        remove_edges = rng.sample(edges, min(k, len(edges)))
        H.remove_edges_from(remove_edges)
    return H

def _pretrain_policy(H, cfg, policy_name, rng):
    if policy_name not in {"rl", "aicof", "aicof_no_gnn", "aicof_no_mlp", "aicof_no_congestion", "aicof_no_fault"}:
        return None
    policy = build_policy(policy_name, H, cfg, rng)
    if isinstance(policy, RLPolicy):
        policy.epsilon = cfg.rl_epsilon_train
    if hasattr(policy, "rl"):
        policy.rl.epsilon = cfg.rl_epsilon_train

    for _ in range(cfg.rl_pretrain_episodes):
        packets = sample_packet_pairs(H.nodes(), max(200, cfg.packets_per_run // 5), cfg.traffic_pattern, cfg.hotspot_fraction, rng)
        queue_len = defaultdict(int)
        link_load = defaultdict(int)
        for src, dst in packets:
            current = src
            visited = {src}
            for _step in range(min(32, cfg.max_steps_per_packet)):
                if current == dst:
                    break
                nxt = policy.choose_next_hop(current, dst, queue_len, link_load, visited)
                if nxt is None or not H.has_edge(current, nxt):
                    break
                queue_len[nxt] += 1
                link_load[(current, nxt)] += 1
                link_load[(nxt, current)] += 1
                curr_dist = policy.shortest_distance(current, dst)
                next_dist = policy.shortest_distance(nxt, dst)
                progress = max(0, curr_dist - next_dist)
                reward = 1.5 * progress - 0.10 * queue_len[nxt] - 0.05 * link_load[(current, nxt)]
                if nxt == dst:
                    reward += 4.0
                if nxt in visited:
                    reward -= 3.0
                if hasattr(policy, "update"):
                    policy.update(current, dst, nxt, reward, queue_len, link_load)
                if nxt == dst or nxt in visited:
                    break
                visited.add(nxt)
                current = nxt
    return policy

def simulate_routing(G, cfg, policy_name, failure_ratio=0.0, seed=42):
    rng = random.Random(seed)
    H = apply_failures(G, failure_ratio, rng)
    if H.number_of_nodes() < 2 or H.number_of_edges() == 0:
        return {
            "connectivity_ratio": 0.0,
            "throughput": 0.0,
            "latency": None,
            "pdr": 0.0,
            "energy_per_packet": None,
            "fault_recovery_score": 0.0,
        }

    pretrained = _pretrain_policy(H, cfg, policy_name, rng)
    if pretrained is not None:
        policy = pretrained
        if isinstance(policy, RLPolicy):
            policy.epsilon = cfg.rl_epsilon_eval
        if hasattr(policy, "rl"):
            policy.rl.epsilon = cfg.rl_epsilon_eval
    else:
        policy = build_policy(policy_name, H, cfg, rng)

    packets = sample_packet_pairs(H.nodes(), cfg.packets_per_run, cfg.traffic_pattern, cfg.hotspot_fraction, rng)

    delivered = 0
    total_hops = 0
    total_latency = 0.0
    total_energy = 0.0
    queue_len = defaultdict(int)
    link_load = defaultdict(int)

    for src, dst in packets:
        current = src
        visited = {src}
        success = False
        for _step in range(cfg.max_steps_per_packet):
            if current == dst:
                success = True
                break
            nxt = policy.choose_next_hop(current, dst, queue_len, link_load, visited)
            if nxt is None or not H.has_edge(current, nxt):
                break

            queue_len[nxt] += 1
            link_load[(current, nxt)] += 1
            link_load[(nxt, current)] += 1

            curr_dist = policy.shortest_distance(current, dst)
            next_dist = policy.shortest_distance(nxt, dst)
            progress = max(0, curr_dist - next_dist)

            hop_latency = 1.0 + 0.03 * queue_len[nxt] + 0.02 * link_load[(current, nxt)] - 0.08 * progress
            hop_latency = max(0.4, hop_latency)
            hop_energy = 0.7 + 0.015 * H.degree(current) + 0.01 * link_load[(current, nxt)]

            total_latency += hop_latency
            total_energy += hop_energy
            total_hops += 1

            reward = 1.5 * progress - 0.08 * queue_len[nxt] - 0.04 * link_load[(current, nxt)]
            if nxt == dst:
                reward += 4.0
                success = True
                if hasattr(policy, "update"):
                    policy.update(current, dst, nxt, reward, queue_len, link_load)
                break

            if nxt in visited:
                reward -= 3.0
                if hasattr(policy, "update"):
                    policy.update(current, dst, nxt, reward, queue_len, link_load)
                break

            if hasattr(policy, "update"):
                policy.update(current, dst, nxt, reward, queue_len, link_load)

            visited.add(nxt)
            current = nxt

        if success:
            delivered += 1

    pdr = delivered / len(packets) if packets else 0.0
    throughput = delivered / max(1, cfg.max_steps_per_packet)
    latency = total_latency / delivered if delivered > 0 else None
    energy_per_packet = total_energy / delivered if delivered > 0 else None
    cr = connectivity_ratio(H)
    fault_recovery_score = 100.0 * (0.55 * pdr + 0.45 * cr)

    return {
        "connectivity_ratio": round(cr, 4),
        "throughput": round(throughput, 4),
        "latency": round(latency, 4) if latency is not None else None,
        "pdr": round(100.0 * pdr, 2),
        "energy_per_packet": round(energy_per_packet, 4) if energy_per_packet is not None else None,
        "fault_recovery_score": round(fault_recovery_score, 2),
    }
