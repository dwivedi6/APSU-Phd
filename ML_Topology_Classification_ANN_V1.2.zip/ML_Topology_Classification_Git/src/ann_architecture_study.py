"""Reproduce the ANN architecture-sensitivity experiment in the revised manuscript."""
from pathlib import Path
import pandas as pd
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "topology_classification_dataset.csv"
OUT = ROOT / "results"
OUT.mkdir(exist_ok=True)

FEATURES = [
    "avg_degree", "diameter", "avg_path_length", "density",
    "path_diversity", "scalability", "connectivity_ratio"
]

df = pd.read_csv(DATA)
train = df[df["nodes"].isin([64, 128, 256])].copy()
test = df[df["nodes"] == 512].copy()

architectures = {
    "7-16-5": (16,),
    "7-32-16-5": (32, 16),
    "7-64-32-5": (64, 32),
}

rows = []
for name, hidden in architectures.items():
    model = Pipeline([
        ("scale", StandardScaler()),
        ("model", MLPClassifier(
            hidden_layer_sizes=hidden,
            activation="relu",
            solver="adam",
            max_iter=2000,
            random_state=42
        ))
    ])
    model.fit(train[FEATURES], train["topology"])
    pred = model.predict(test[FEATURES])
    rows.append({
        "Architecture": name,
        "Hidden_Layers": str(hidden),
        "Accuracy": accuracy_score(test["topology"], pred),
        "Precision_weighted": precision_score(test["topology"], pred, average="weighted", zero_division=0),
        "Recall_weighted": recall_score(test["topology"], pred, average="weighted", zero_division=0),
        "F1_weighted": f1_score(test["topology"], pred, average="weighted", zero_division=0),
    })

results = pd.DataFrame(rows)
results.to_csv(OUT / "ann_architecture_results.csv", index=False)
print(results.to_string(index=False))
