# Machine Learning-Based Topology Classification — Reproducibility Package

This repository contains the **test data and classifier-evaluation code** used for the manuscript:

> **Machine Learning-Based Classification of Processor Interconnection Networks Based on Structural Connectivity and Complexity**

## What is included

```text
.
├── data/
│   └── topology_classification_dataset.csv
├── figures/
│   ├── fig_accuracy_comparison.png
│   ├── fig_confusion_matrix.png
│   └── fig_feature_importance.png
├── results/
├── src/
│   ├── reproduce_results.py
│   └── run_all.py
├── DATA_DICTIONARY.md
├── requirements.txt
└── README.md
```

## Experimental design

Five topology families are represented:

- Hypercube
- Torus
- Fat-Tree
- Dragonfly-like
- Perfect Difference Network (PDN)

Network sizes are 64, 128, 256, and 512 nodes. Controlled edge-failure levels are 0%, 1%, 2%, and 5%, with five repetitions for each topology-size-failure combination, giving:

`5 × 4 × 4 × 5 = 400` graph instances.

The cross-size protocol is:

- **Training:** 64, 128, 256 nodes (300 instances)
- **Held-out test:** 512 nodes (100 instances)

Seven graph-level features are used by the classifiers:

1. Average degree
2. Diameter
3. Average shortest-path length
4. Density
5. Path-diversity structural proxy
6. Inverse average path length proxy (stored as `scalability` in the supplied CSV for compatibility with the manuscript dataset)
7. Connectivity ratio

## Classifiers

- Decision Tree: `max_depth=6`
- KNN: `k=5`
- SVM: RBF kernel, `C=2`
- Random Forest: 200 trees, `max_depth=8`
- MLP: hidden layers `(32, 16)`

KNN, SVM, and MLP use standardization. Tree-based models do not require scaling.

## Run the experiment

Install dependencies:

```bash
pip install -r requirements.txt
```

Then run:

```bash
python src/run_all.py
```

The script creates:

- `results/classification_results.csv`
- `results/decision_tree_confusion_matrix.csv`
- `results/random_forest_feature_importance.csv`

The verified results from the supplied dataset are:

| Classifier | Accuracy | Precision | Recall | F1 |
|---|---:|---:|---:|---:|
| Decision Tree | 1.00 | 1.00 | 1.00 | 1.00 |
| KNN | 0.80 | 0.70 | 0.80 | 0.7333 |
| SVM | 0.60 | 0.50 | 0.60 | 0.5333 |
| Random Forest | 0.80 | 0.70 | 0.80 | 0.7333 |
| MLP | 1.00 | 1.00 | 1.00 | 1.00 |

## Important reproducibility note

The **exact 400-row feature dataset used in the manuscript is included**. The current working package did not contain the original graph-generator source code that produced that CSV. Therefore, this repository should be described as containing the **manuscript dataset and result-reproduction code**, not as a byte-for-byte reconstruction of the original topology-generation program.

The supplied CSV is the authoritative test dataset for reproducing the reported classifier metrics. The simplified Fat-Tree and Dragonfly-like topology descriptions in the manuscript should not be interpreted as hardware-level implementations.

If the original topology-generation program is recovered, it should replace or supplement this package before making a claim of full end-to-end simulation reproducibility.

## Data availability statement for the paper

A concise statement suitable for the manuscript is:

> **Data Availability:** The dataset generated and analyzed in this study, together with the classifier evaluation scripts used to reproduce the reported results, is available in the associated GitHub repository.

## Citation

When publishing the repository, add the final GitHub URL and a version tag/DOI if available.

## ANN architecture sensitivity

`src/ann_architecture_study.py` reproduces the ANN architecture-sensitivity experiment added to the revised manuscript.

Architectures:
- 7–16–5
- 7–32–16–5 (baseline ANN/MLP)
- 7–64–32–5

All models use the seven structural features, StandardScaler preprocessing, ReLU hidden activations, Adam optimization, `random_state=42`, and a maximum of 2000 iterations. Training uses 64/128/256-node instances; all 512-node instances are held out for testing.

Results are written to `results/ann_architecture_results.csv`.
