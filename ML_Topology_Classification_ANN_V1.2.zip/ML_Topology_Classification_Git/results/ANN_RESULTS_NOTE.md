# ANN results

The revised manuscript reports the following held-out 512-node results:

| Architecture | Accuracy | Precision | Recall | F1 |
|---|---:|---:|---:|---:|
| 7–16–5 | 80% | 70% | 80% | 73.33% |
| 7–32–16–5 | 100% | 100% | 100% | 100% |
| 7–64–32–5 | 100% | 100% | 100% | 100% |

The 7–32–16–5 architecture is retained as the baseline ANN/MLP configuration in the manuscript.
