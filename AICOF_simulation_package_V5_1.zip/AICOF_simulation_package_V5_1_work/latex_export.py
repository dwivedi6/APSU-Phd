from pathlib import Path
import pandas as pd
def df_to_latex_table(df, caption, label, outpath):
    cols = list(df.columns); colspec = "l" + "c" * (len(cols) - 1)
    def fmt(x):
        if pd.isna(x): return "--"
        if isinstance(x, float): return f"{x:.4f}".rstrip("0").rstrip(".")
        return str(x)
    lines = [r"\begin{table*}[t]", r"\centering", rf"\caption{{{caption}}}", rf"\label{{{label}}}", rf"\begin{{tabular}}{{{colspec}}}", r"\hline", " & ".join(cols) + r" \\", r"\hline"]
    for _, row in df.iterrows(): lines.append(" & ".join(fmt(row[c]) for c in cols) + r" \\")
    lines += [r"\hline", r"\end{tabular}", r"\end{table*}"]
    Path(outpath).write_text("\n".join(lines), encoding="utf-8")
