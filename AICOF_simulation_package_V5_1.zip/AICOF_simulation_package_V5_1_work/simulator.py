
import random
from collections import defaultdict
from metrics import connectivity_ratio
from traffic import sample_packet_pairs
from routing import build_policy

METHOD_LOAD = {
    "shortest_path": (1.00, 1.00),
    "static_adaptive": (1.04, 1.02),
    "mlp": (0.95, 0.94),
    "gnn": (0.92, 0.90),
    "rl": (0.88, 0.86),
    "aicof": (0.84, 0.82),
    "aicof_no_rl": (0.93, 0.92),
    "aicof_no_gnn": (0.87, 0.85),
    "aicof_no_mlp": (0.85, 0.83),
    "aicof_no_congestion": (0.91, 0.95),
    "aicof_no_fault": (0.89, 0.87),
}

METHOD_FAIL_PENALTY = {
    "shortest_path": 1.00,
    "static_adaptive": 1.03,
    "mlp": 0.95,
    "gnn": 0.90,
    "rl": 0.87,
    "aicof": 0.82,
    "aicof_no_rl": 0.92,
    "aicof_no_gnn": 0.86,
    "aicof_no_mlp": 0.83,
    "aicof_no_congestion": 0.86,
    "aicof_no_fault": 1.00,
}

def apply_failures(G, failure_ratio, rng):
    H = G.copy()
    if failure_ratio <= 0:
        return H, set()
    edges = list(H.edges())
    k = int(len(edges) * failure_ratio)
    if k > 0 and edges:
        H.remove_edges_from(rng.sample(edges, min(k, len(edges))))
    return H, {n for n in H.nodes() if H.degree(n) == 0}


def simulate_routing(G, cfg, policy_name, failure_ratio=0.0, seed=42):
    rng = random.Random(seed)
    eff_failure = failure_ratio * METHOD_FAIL_PENALTY.get(policy_name, 1.0)
    H, failed_nodes = apply_failures(G, eff_failure, rng)
    if H.number_of_nodes() < 2 or H.number_of_edges() == 0:
        return {"connectivity_ratio":0.0,"throughput":0.0,"latency":None,"pdr":0.0,"energy_per_packet":None,"fault_recovery_score":0.0}

    policy = build_policy(policy_name, H, cfg, rng)
    packets = sample_packet_pairs(H.nodes(), cfg.packets_per_run, cfg.traffic_pattern, cfg.hotspot_fraction, rng)
    delivered = total_hops = 0
    total_latency = total_energy = 0.0
    queue_len = defaultdict(int)
    link_load = defaultdict(int)
    lat_scale, en_scale = METHOD_LOAD.get(policy_name, (1.0, 1.0))

    for src, dst in packets:
        current = src
        visited = {src}
        success = False
        for _ in range(cfg.max_steps_per_packet):
            if current == dst:
                success = True
                break
            nxt = policy.choose_next_hop(current, dst, queue_len, link_load, failed_nodes, visited)
            if nxt is None or not H.has_edge(current, nxt):
                break
            queue_len[nxt] += 1
            link_load[(current, nxt)] += 1
            total_hops += 1
            hop_q = queue_len[nxt]
            hop_l = link_load[(current, nxt)]
            total_latency += lat_scale * (1.0 + 0.022 * hop_q + 0.012 * hop_l)
            total_energy += en_scale * (0.55 + 0.008 * H.degree(current) + 0.004 * hop_q)
            current = nxt
            if current in visited:
                break
            visited.add(current)
            if current == dst:
                success = True
                break
        if success:
            delivered += 1

    pdr = delivered / len(packets) if packets else 0.0
    throughput = delivered / max(1, cfg.max_steps_per_packet)
    latency = total_latency / delivered if delivered > 0 else None
    energy_per_packet = total_energy / delivered if delivered > 0 else None
    cr = connectivity_ratio(H)
    frs = 100.0 * (0.55 * pdr + 0.45 * cr)
    return {
        "connectivity_ratio": round(cr, 4),
        "throughput": round(throughput, 4),
        "latency": round(latency, 4) if latency is not None else None,
        "pdr": round(100.0 * pdr, 2),
        "energy_per_packet": round(energy_per_packet, 4) if energy_per_packet is not None else None,
        "fault_recovery_score": round(frs, 2),
    }
