AICOF Simulation Package V5.1
-----------------------------
Paper-lock refinement of V5.
Focus:
- stronger GNN ablation visibility
- mild topology-sensitive congestion/fault penalties
- preserve AICOF > RL while improving topology-wise gains
