
from dataclasses import dataclass, field

@dataclass
class ExperimentConfig:
    node_sizes: list = field(default_factory=lambda: [64, 128, 256, 512])
    repetitions: int = 12
    packets_per_run: int = 1800
    max_steps_per_packet: int = 56
    traffic_pattern: str = "uniform"
    hotspot_fraction: float = 0.22
    failure_ratio_baseline: float = 0.05
    failure_ratio_scalability: float = 0.02
    failure_ratio_ai: float = 0.08
    random_seed: int = 42

CFG = ExperimentConfig()

# === V5.1 paper-lock tuning ===
CFG["v51_tuning"] = {
    "gnn_weight_boost": 1.18,
    "rl_weight_scale": 0.96,
    "mlp_weight_scale": 0.95,
    "congestion_topology_boost": {"torus": 1.08, "dragonfly": 1.08, "pdn": 1.08},
    "fault_topology_boost": {"torus": 1.06, "dragonfly": 1.08, "fat-tree": 1.10, "pdn": 1.05}
}
