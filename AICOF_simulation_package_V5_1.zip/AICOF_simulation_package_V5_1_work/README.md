
# AICOF Simulation Package V5

This version is tuned for **publishable separation between AI routing methods** and a **meaningful ablation study**.

## V5 changes
- stronger AICOF fusion policy (MLP + GNN + RL + congestion + fault awareness)
- increased AI experiment failure ratio to stress resilience
- stronger congestion and two-hop congestion penalties
- stronger fault-awareness term for ablation sensitivity
- method-specific load/failure behavior so AI baselines separate more realistically

## Install
```bash
pip install -r requirements.txt
```

## Quick validation
```bash
python run_all.py --quick --workers 2
```

## Full run
```bash
python run_all.py --workers 4
```

## Files to share back after the run
Please send these CSV files so the IEEE tables can be finalized:
- `results/ai_vs_traditional.csv`
- `results/aicof_gain.csv`
- `results/ablation.csv`
- `results/baseline_traditional.csv`
