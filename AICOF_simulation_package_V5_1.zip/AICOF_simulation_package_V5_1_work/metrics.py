import networkx as nx, numpy as np
def safe_average_shortest_path_length(G):
    if G.number_of_nodes() <= 1: return 0.0
    if nx.is_connected(G): return nx.average_shortest_path_length(G)
    H = G.subgraph(max(nx.connected_components(G), key=len)).copy()
    return nx.average_shortest_path_length(H) if H.number_of_nodes() > 1 else 0.0
def structural_metrics(G):
    degrees = [d for _, d in G.degree()]; avg_degree = float(np.mean(degrees)) if degrees else 0.0
    if G.number_of_nodes() <= 1: diameter = 0
    else:
        if nx.is_connected(G): diameter = nx.diameter(G)
        else:
            H = G.subgraph(max(nx.connected_components(G), key=len)).copy()
            diameter = nx.diameter(H) if H.number_of_nodes() > 1 else 0
    avg_path = safe_average_shortest_path_length(G); density = nx.density(G)
    edge_conn = nx.edge_connectivity(G) if G.number_of_nodes() > 1 else 0
    node_conn = nx.node_connectivity(G) if G.number_of_nodes() > 1 else 0
    return {"node_degree": round(avg_degree,4), "diameter": int(diameter), "avg_path_length": round(avg_path,4),
            "path_diversity": round(density * avg_degree,4), "scalability": round(1.0/(avg_path+1e-9) if avg_path>0 else 0.0,6),
            "fault_tolerance": round((edge_conn + node_conn)/2.0,4)}
def connectivity_ratio(G):
    if G.number_of_nodes() == 0: return 0.0
    largest = max(nx.connected_components(G), key=len)
    return len(largest) / G.number_of_nodes()
