import argparse
from pathlib import Path
from config import CFG
from experiments import run_structural_table, run_baseline_table, run_scalability_tables, run_ai_vs_traditional, run_aicof_gain, run_ablation
from latex_export import df_to_latex_table
from utils import StageTimer, log, ensure_dir
def save_with_latex(df, csv_path, tex_path, caption, label):
    df.to_csv(csv_path, index=False); df_to_latex_table(df, caption, label, tex_path)
def main():
    parser = argparse.ArgumentParser(); parser.add_argument("--quick", action="store_true"); parser.add_argument("--workers", type=int, default=1); args = parser.parse_args()
    if args.quick:
        CFG.repetitions = 4; CFG.packets_per_run = 500; CFG.max_steps_per_packet = 32
        log("[Quick mode] repetitions=4, packets_per_run=500, max_steps_per_packet=32")
    else:
        log("[Full mode] using config.py settings")
    log(f"[Config] workers={args.workers}, repetitions={CFG.repetitions}, packets_per_run={CFG.packets_per_run}, node_sizes={CFG.node_sizes}")
    out = Path("results"); ensure_dir(out)
    with StageTimer("1/6 Topology structural table"):
        df = run_structural_table(node_count=64); save_with_latex(df, out/"topology_structural.csv", out/"table_topology_structural.tex", "Topology-wise structural and communication characteristics.", "tab:topology_structural")
    with StageTimer("2/6 Baseline traditional-routing table"):
        df = run_baseline_table(node_count=64, workers=args.workers); save_with_latex(df, out/"baseline_traditional.csv", out/"table_baseline_traditional.tex", "Baseline performance of interconnection topologies under traditional shortest-path routing.", "tab:baseline_traditional")
    with StageTimer("3/6 Scalability tables"):
        lat, thr = run_scalability_tables(workers=args.workers)
        save_with_latex(lat, out/"scalability_latency.csv", out/"table_scalability_latency.tex", "Scalability analysis of topologies with increasing network size (latency).", "tab:scalability_latency")
        save_with_latex(thr, out/"scalability_throughput.csv", out/"table_scalability_throughput.tex", "Scalability analysis of topologies with increasing network size (throughput).", "tab:scalability_throughput")
    with StageTimer("4/6 AI vs traditional routing"):
        df = run_ai_vs_traditional(node_count=256, workers=args.workers); save_with_latex(df, out/"ai_vs_traditional.csv", out/"table_ai_vs_traditional.tex", "Performance comparison between traditional routing and AI-assisted routing.", "tab:ai_vs_traditional")
    with StageTimer("5/6 AICOF gain table"):
        df = run_aicof_gain(node_count=256, workers=args.workers); save_with_latex(df, out/"aicof_gain.csv", out/"table_aicof_gain.tex", "Topology-wise improvement of AICOF over traditional shortest-path routing.", "tab:aicof_gain")
    with StageTimer("6/6 Ablation table"):
        df = run_ablation(node_count=256, workers=args.workers); save_with_latex(df, out/"ablation.csv", out/"table_ablation.tex", "Ablation study of the proposed AICOF framework.", "tab:ablation")
    log("\nAll experiment tables generated in ./results")
if __name__ == "__main__": main()
